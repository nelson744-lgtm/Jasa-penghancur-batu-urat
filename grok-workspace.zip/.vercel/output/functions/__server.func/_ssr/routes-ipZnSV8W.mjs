import { i as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as greetingId, n as extractYoutubeId, r as formatTime, t as cn } from "./utils-BhS6FQuj.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { S as ChevronDown, _ as ListMusic, a as SkipForward, b as Heart, c as Search, d as Repeat1, f as Play, g as ListPlus, h as LoaderCircle, l as SearchX, m as Music2, n as VolumeX, o as SkipBack, p as Pause, r as Volume2, s as Shuffle, t as X, u as Repeat, v as House, x as Film, y as History } from "../_libs/lucide-react.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ipZnSV8W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,color,opacity,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:enabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "text-foreground hover:bg-accent",
			outline: "bg-transparent shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-accent",
			subtle: "bg-transparent text-muted-foreground hover:text-foreground hover:bg-accent"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-9 rounded-md px-3",
			lg: "h-11 rounded-lg px-5",
			icon: "size-11 rounded-full",
			pill: "h-10 rounded-full px-4"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-full bg-secondary px-4 text-sm text-foreground shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var engine = null;
function bindPlayerEngine(next) {
	engine = next;
}
function remember(history, track) {
	return [track, ...history.filter((item) => item.id !== track.id)].slice(0, 40);
}
var usePlayerStore = create()(persist((set, get) => ({
	mode: "music",
	current: null,
	queue: [],
	queueIndex: 0,
	isPlaying: false,
	isReady: false,
	currentTime: 0,
	duration: 0,
	volume: .8,
	muted: false,
	shuffle: false,
	repeat: "off",
	likes: [],
	history: [],
	stageOpen: false,
	queueOpen: false,
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	setMode: (mode) => {
		set({
			mode,
			stageOpen: true
		});
		engine?.setMusicQuality(mode === "music");
	},
	setReady: (isReady) => set({ isReady }),
	setProgress: (currentTime, duration) => set({
		currentTime,
		duration
	}),
	setPlaying: (isPlaying) => set({ isPlaying }),
	playTrack: (track, list) => {
		const queue = list && list.length > 0 ? uniqueQueue(list, track) : [track];
		set({
			current: track,
			queue,
			queueIndex: Math.max(0, queue.findIndex((item) => item.id === track.id)),
			isPlaying: true,
			currentTime: 0,
			duration: track.durationSeconds || 0,
			stageOpen: true,
			history: remember(get().history, track)
		});
		engine?.load(track.id);
	},
	playAt: (index) => {
		const { queue } = get();
		const track = queue[index];
		if (!track) return;
		set({
			current: track,
			queueIndex: index,
			isPlaying: true,
			currentTime: 0,
			duration: track.durationSeconds || 0,
			history: remember(get().history, track)
		});
		engine?.load(track.id);
	},
	togglePlay: () => {
		const { current, isPlaying } = get();
		if (!current) return;
		if (isPlaying) {
			engine?.pause();
			set({ isPlaying: false });
		} else {
			engine?.play();
			set({ isPlaying: true });
		}
	},
	next: () => {
		const { repeat, shuffle, queueIndex, queue, current } = get();
		if (!current) return;
		if (repeat === "one") {
			engine?.seekTo(0);
			engine?.play();
			set({
				isPlaying: true,
				currentTime: 0
			});
			return;
		}
		if (shuffle && queue.length > 1) {
			const others = queue.map((_, i) => i).filter((i) => i !== queueIndex);
			const pick = others[Math.floor(Math.random() * others.length)] ?? 0;
			get().playAt(pick);
			return;
		}
		const nextIndex = queueIndex + 1;
		if (nextIndex < queue.length) {
			get().playAt(nextIndex);
			return;
		}
		if (repeat === "all" && queue.length > 0) {
			get().playAt(0);
			return;
		}
		engine?.pause();
		set({ isPlaying: false });
	},
	prev: () => {
		const { currentTime, queueIndex, queue } = get();
		if (currentTime > 3 || queueIndex <= 0) {
			engine?.seekTo(0);
			set({
				currentTime: 0,
				isPlaying: true
			});
			engine?.play();
			return;
		}
		if (queue[queueIndex - 1]) get().playAt(queueIndex - 1);
	},
	seek: (seconds) => {
		engine?.seekTo(seconds);
		set({ currentTime: seconds });
	},
	setVolume: (volume) => {
		const next = Math.min(1, Math.max(0, volume));
		set({
			volume: next,
			muted: next === 0
		});
		engine?.setVolume(next);
		if (next === 0) engine?.mute();
		else engine?.unMute();
	},
	toggleMute: () => {
		const { muted, volume } = get();
		if (muted) {
			engine?.unMute();
			engine?.setVolume(volume || .8);
			set({
				muted: false,
				volume: volume || .8
			});
		} else {
			engine?.mute();
			set({ muted: true });
		}
	},
	toggleShuffle: () => set({ shuffle: !get().shuffle }),
	cycleRepeat: () => {
		const order = [
			"off",
			"all",
			"one"
		];
		const current = get().repeat;
		set({ repeat: order[(order.indexOf(current) + 1) % order.length] ?? "off" });
	},
	toggleLike: (track) => {
		const target = track ?? get().current;
		if (!target) return;
		const { likes } = get();
		set({ likes: likes.some((item) => item.id === target.id) ? likes.filter((item) => item.id !== target.id) : [target, ...likes].slice(0, 100) });
	},
	isLiked: (id) => get().likes.some((item) => item.id === id),
	addToQueue: (track) => {
		const { queue, current } = get();
		if (queue.some((item) => item.id === track.id)) return;
		if (!current) {
			get().playTrack(track);
			return;
		}
		set({ queue: [...queue, track] });
	},
	removeFromQueue: (index) => {
		const { queue, queueIndex } = get();
		if (index === queueIndex) return;
		set({
			queue: queue.filter((_, i) => i !== index),
			queueIndex: index < queueIndex ? queueIndex - 1 : queueIndex
		});
	},
	setStageOpen: (stageOpen) => set({ stageOpen }),
	setQueueOpen: (queueOpen) => set({ queueOpen }),
	appendRelated: (tracks) => {
		const { queue, current } = get();
		if (!current || tracks.length === 0) return;
		if (queue.length > 1) return;
		const extra = tracks.filter((track) => track.id !== current.id && !queue.some((item) => item.id === track.id));
		if (extra.length === 0) return;
		set({ queue: [...queue, ...extra] });
	}
}), {
	name: "nada-player-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		mode: state.mode,
		volume: state.volume,
		muted: state.muted,
		shuffle: state.shuffle,
		repeat: state.repeat,
		likes: state.likes,
		history: state.history
	})
}));
function uniqueQueue(list, first) {
	return [first, ...list.filter((item) => item.id !== first.id)];
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var searchInput = object({ query: string().min(1).max(200) });
var searchYoutube = createServerFn({ method: "POST" }).validator(searchInput).handler(createSsrRpc("7df3dd16e784b248b7d886a0783a467b063c331e19af46955cb1384e05116dfc"));
var suggestYoutube = createServerFn({ method: "POST" }).validator(searchInput).handler(createSsrRpc("37b4ff33f5cc3af2ecb5f1e50e9379e7d8f1f74e87e60d09dc0dbcf2d904f880"));
var getRelated = createServerFn({ method: "POST" }).validator(object({ videoId: string().regex(/^[\w-]{11}$/) })).handler(createSsrRpc("4fee74457b336958e838f0859030ebd73f452b570d87b3206d15941f82ffb01b"));
var resolveVideo = createServerFn({ method: "POST" }).validator(object({ videoId: string().regex(/^[\w-]{11}$/) })).handler(createSsrRpc("12de13b4b588c7ab1a8151c83501d7cadeddf5ae6d69fb6dd149fcd90514d7de"));
var getHomeFeed = createServerFn({ method: "GET" }).handler(createSsrRpc("a5694f4614a0cb2612bc92a0a839d3a7320fa9c0d85e1190a757f45efb7dc567"));
function SearchHeader() {
	const navigate = useNavigate();
	const query = useSearch({ from: "/" }).q ?? "";
	const [value, setValue] = (0, import_react.useState)(query);
	const [open, setOpen] = (0, import_react.useState)(false);
	const formRef = (0, import_react.useRef)(null);
	const mode = usePlayerStore((s) => s.mode);
	const setMode = usePlayerStore((s) => s.setMode);
	(0, import_react.useEffect)(() => {
		setValue(query);
	}, [query]);
	const suggestions = useQuery({
		queryKey: ["suggest", value],
		queryFn: () => suggestYoutube({ data: { query: value } }),
		enabled: value.trim().length >= 2 && value.trim() !== query,
		staleTime: 3e4
	});
	const submit = (next) => {
		const q = next.trim();
		setOpen(false);
		navigate({
			to: "/",
			search: q ? { q } : {}
		});
	};
	const items = suggestions.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:gap-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex shrink-0 items-baseline gap-1.5",
					onClick: () => {
						setValue("");
						navigate({
							to: "/",
							search: {}
						});
					},
					"aria-label": "Beranda Nada",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl italic tracking-tight text-foreground sm:text-2xl",
						children: "Nada"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					ref: formRef,
					className: "relative min-w-0 flex-1",
					onSubmit: (event) => {
						event.preventDefault();
						submit(value);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value,
							onChange: (event) => {
								setValue(event.target.value);
								setOpen(true);
							},
							onFocus: () => setOpen(true),
							onBlur: () => window.setTimeout(() => setOpen(false), 120),
							placeholder: "Cari lagu, artis, atau tautan YouTube",
							className: "h-11 bg-secondary/80 pr-11 pl-10",
							"aria-label": "Cari musik atau video",
							autoComplete: "off",
							enterKeyHint: "search"
						}),
						value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute top-1/2 right-2 grid size-8 -translate-y-1/2 place-items-center rounded-full text-muted-foreground hover:text-foreground",
							"aria-label": "Hapus pencarian",
							onClick: () => {
								setValue("");
								submit("");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : suggestions.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "absolute top-1/2 right-3.5 size-4 -translate-y-1/2 animate-spin text-muted-foreground" }) : null,
						open && items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "absolute inset-x-0 top-[calc(100%+8px)] z-50 overflow-hidden rounded-2xl bg-popover py-2 shadow-[var(--shadow-border),var(--shadow-lift)]",
							children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm hover:bg-accent",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => {
									setValue(item);
									submit(item);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: item
								})]
							}) }, item))
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative grid shrink-0 grid-cols-2 rounded-full bg-secondary p-1",
					role: "radiogroup",
					"aria-label": "Mode putar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-full bg-primary transition-transform duration-200 ease-[var(--ease-smooth-out)]", mode === "video" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"),
							"aria-hidden": true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							role: "radio",
							"aria-checked": mode === "music",
							className: cn("relative z-10 h-8 rounded-full px-2.5 text-xs sm:px-3", mode === "music" ? "text-primary-foreground hover:bg-transparent" : "text-muted-foreground"),
							onClick: () => setMode("music"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Musik"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							role: "radio",
							"aria-checked": mode === "video",
							className: cn("relative z-10 h-8 rounded-full px-2.5 text-xs sm:px-3", mode === "video" ? "text-primary-foreground hover:bg-transparent" : "text-muted-foreground"),
							onClick: () => setMode("video"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Video"
							})]
						})
					]
				})
			]
		})
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-foreground/8", className),
		...props
	});
}
function VideoCard({ track, queue, layout = "grid", index = 0 }) {
	const currentId = usePlayerStore((s) => s.current?.id);
	const isPlaying = usePlayerStore((s) => s.isPlaying);
	const playTrack = usePlayerStore((s) => s.playTrack);
	const addToQueue = usePlayerStore((s) => s.addToQueue);
	const active = currentId === track.id;
	const onPlay = () => playTrack(track, queue);
	if (layout === "row") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("group flex items-center gap-3 rounded-xl p-2 pr-3 transition-[background-color] duration-150 hover:bg-accent", active && "bg-accent"),
		style: { animationDelay: `calc(var(--motion-stagger) * ${Math.min(index, 12)})` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onPlay,
				className: "relative size-14 shrink-0 overflow-hidden rounded-lg bg-secondary tap-press",
				"aria-label": `Putar ${track.title}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: track.thumbnail,
					alt: "",
					className: "size-full object-cover",
					loading: "lazy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-0 grid place-items-center bg-ink/40 opacity-0 transition-opacity duration-150 group-hover:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current text-foreground" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onPlay,
				className: "min-w-0 flex-1 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("truncate text-sm font-medium", active && "text-primary"),
					children: track.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: [track.channel, track.durationLabel ? ` · ${track.durationLabel}` : ""]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-10 shrink-0 text-muted-foreground",
				"aria-label": "Tambah ke antrian",
				onClick: () => {
					addToQueue(track);
					toast("Ditambahkan ke antrian");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListPlus, { className: "size-4" })
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("group rise-in", layout === "rail" ? "w-[168px] shrink-0 snap-start sm:w-[200px]" : "w-full"),
		style: { animationDelay: `calc(var(--motion-stagger) * ${Math.min(index, 12)})` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onPlay,
			className: "relative block w-full overflow-hidden rounded-xl bg-secondary tap-press",
			"aria-label": `Putar ${track.title}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative block aspect-video",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: track.thumbnail,
						alt: "",
						className: "size-full object-cover transition-[transform] duration-300 ease-[var(--ease-smooth-out)] group-hover:scale-[1.03]",
						loading: "lazy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute right-2 bottom-2 rounded-md bg-ink/80 px-1.5 py-0.5 text-[11px] font-medium tabular-nums text-foreground",
						children: track.durationLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-0 grid place-items-center opacity-0 transition-opacity duration-150 group-hover:opacity-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-12 place-items-center rounded-full bg-primary text-primary-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current ml-0.5" })
						})
					}),
					active && isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute top-2 left-2 flex h-5 items-end gap-0.5 rounded-md bg-ink/80 px-1.5 py-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "eq-bar inline-block h-3 w-0.5 bg-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "eq-bar inline-block h-3 w-0.5 bg-primary [animation-delay:-0.2s]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "eq-bar inline-block h-3 w-0.5 bg-primary [animation-delay:-0.4s]" })
						]
					}) : null
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2.5 flex items-start gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onPlay,
				className: "min-w-0 flex-1 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: cn("line-clamp-2 text-sm font-medium leading-snug", active && "text-primary"),
					children: track.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 truncate text-xs text-muted-foreground",
					children: track.channel
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-8 shrink-0 text-muted-foreground opacity-100 sm:opacity-0 sm:group-hover:opacity-100",
				"aria-label": "Tambah ke antrian",
				onClick: () => {
					addToQueue(track);
					toast("Ditambahkan ke antrian");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListPlus, { className: "size-4" })
			})]
		})]
	});
}
function Catalog() {
	const search = useSearch({ from: "/" });
	const query = search.q?.trim() ?? "";
	const tab = search.tab ?? "home";
	if (query) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchResults, { query });
	if (tab === "likes") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryList, { kind: "likes" });
	if (tab === "history") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryList, { kind: "history" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseHome, {});
}
function CatalogTabs() {
	const search = useSearch({ from: "/" });
	const navigate = useNavigate();
	const query = search.q?.trim() ?? "";
	const tab = search.tab ?? "home";
	if (query) return null;
	const go = (next) => {
		navigate({
			to: "/",
			search: next === "home" ? {} : { tab: next }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabChip, {
				active: tab === "home",
				onClick: () => go("home"),
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-3.5" }),
				children: "Jelajah"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabChip, {
				active: tab === "likes",
				onClick: () => go("likes"),
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5" }),
				children: "Disukai"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabChip, {
				active: tab === "history",
				onClick: () => go("history"),
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5" }),
				children: "Riwayat"
			})
		]
	});
}
function TabChip({ active, onClick, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: active ? "default" : "secondary",
		size: "pill",
		className: "h-9",
		onClick,
		children: [icon, children]
	});
}
function BrowseHome() {
	const feed = useQuery({
		queryKey: ["home-feed"],
		queryFn: () => getHomeFeed()
	});
	const playTrack = usePlayerStore((s) => s.playTrack);
	const [hello, setHello] = (0, import_react.useState)("Selamat datang");
	(0, import_react.useEffect)(() => {
		setHello(greetingId());
	}, []);
	if (feed.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Katalog belum bisa dimuat",
		body: feed.error instanceof Error ? feed.error.message : "Coba muat ulang.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			onClick: () => void feed.refetch(),
			children: "Coba lagi"
		})
	});
	const hero = feed.data?.[0]?.tracks[0];
	const heroQueue = feed.data?.[0]?.tracks ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: hello
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 max-w-xl text-3xl leading-tight tracking-tight italic sm:text-4xl",
					children: "Putar apa saja dari YouTube, tanpa ribet."
				})]
			}),
			feed.isLoading || !hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroSkeleton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "relative overflow-hidden rounded-3xl bg-card shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-0 md:grid-cols-[1.3fr_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative aspect-video overflow-hidden md:aspect-auto md:min-h-[280px]",
						onClick: () => playTrack(hero, heroQueue),
						"aria-label": `Putar ${hero.title}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: hero.thumbnail,
							alt: "",
							className: "size-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-gradient-to-r from-ink/80 via-ink/20 to-transparent" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-end gap-4 p-5 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
								children: "Pilihan hari ini"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl leading-snug tracking-tight italic",
								children: hero.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: hero.channel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "lg",
								className: "rounded-full",
								onClick: () => playTrack(hero, heroQueue),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current ml-0.5" }), "Putar"]
							}) })
						]
					})]
				})
			}),
			feed.isLoading ? Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailSkeleton, {}, i)) : feed.data?.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium tracking-tight",
						children: section.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: section.subtitle
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rail",
					children: section.tracks.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
						track,
						queue: section.tracks,
						layout: "rail",
						index
					}, track.id))
				})]
			}, section.id))
		]
	});
}
function SearchResults({ query }) {
	const videoId = extractYoutubeId(query);
	const playTrack = usePlayerStore((s) => s.playTrack);
	const playedId = (0, import_react.useRef)(null);
	const resolved = useQuery({
		queryKey: ["resolve", videoId],
		queryFn: () => resolveVideo({ data: { videoId } }),
		enabled: Boolean(videoId)
	});
	const results = useQuery({
		queryKey: ["search", query],
		queryFn: () => searchYoutube({ data: { query } }),
		enabled: !videoId
	});
	(0, import_react.useEffect)(() => {
		if (!resolved.data) return;
		if (playedId.current === resolved.data.id) return;
		playedId.current = resolved.data.id;
		playTrack(resolved.data);
	}, [playTrack, resolved.data]);
	if (videoId) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Membuka tautan YouTube…"
		}), resolved.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Tautan tidak bisa dibuka",
			body: resolved.error instanceof Error ? resolved.error.message : "Coba tempel ulang."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {})]
	});
	if (results.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
		className: "mb-4 text-lg font-medium",
		children: [
			"Mencari “",
			query,
			"”"
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {})] });
	if (results.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Pencarian gagal",
		body: results.error instanceof Error ? results.error.message : "Coba lagi.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			onClick: () => void results.refetch(),
			children: "Coba lagi"
		})
	});
	const tracks = results.data?.tracks ?? [];
	if (tracks.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Tidak ada hasil",
		body: `Tidak ketemu untuk “${query}”. Coba judul lagu atau nama artis.`
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "mb-1 text-lg font-medium",
			children: [
				"Hasil untuk “",
				query,
				"”"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-5 text-sm text-muted-foreground",
			children: [tracks.length, " video"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4",
			children: tracks.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
				track,
				queue: tracks,
				layout: "grid",
				index
			}, track.id))
		})
	] });
}
function LibraryList({ kind }) {
	const hydrated = usePlayerStore((s) => s.hydrated);
	const likes = usePlayerStore((s) => s.likes);
	const history = usePlayerStore((s) => s.history);
	const tracks = kind === "likes" ? likes : history;
	const title = kind === "likes" ? "Disukai" : "Riwayat";
	const empty = kind === "likes" ? "Lagu yang kamu sukai akan terkumpul di sini." : "Putar sesuatu, riwayatnya akan muncul di sini.";
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {});
	if (tracks.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title,
		body: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "mb-5 text-lg font-medium",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4",
		children: tracks.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
			track,
			queue: tracks,
			layout: "grid",
			index
		}, track.id))
	})] });
}
function EmptyState({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center gap-3 px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchX, { className: "size-8 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted-foreground",
				children: body
			}),
			action
		]
	});
}
function HeroSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-[280px] w-full rounded-3xl" });
}
function RailSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mb-3 h-5 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-3 overflow-hidden",
		children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-[168px] shrink-0 sm:w-[200px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-video w-full rounded-xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-2 h-4 w-4/5" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-1 h-3 w-1/2" })
			]
		}, i))
	})] });
}
function GridSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4",
		children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-video w-full rounded-xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-2 h-4 w-4/5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-1 h-3 w-1/2" })
		] }, i))
	});
}
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center py-2", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-foreground/12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-3.5 rounded-full bg-primary shadow-sm ring-offset-background transition-[box-shadow,transform] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none" })]
}));
Slider.displayName = Slider$1.displayName;
function PlayerChrome() {
	const current = usePlayerStore((s) => s.current);
	const appendRelated = usePlayerStore((s) => s.appendRelated);
	const related = useQuery({
		queryKey: ["related", current?.id],
		queryFn: () => getRelated({ data: { videoId: current.id } }),
		enabled: Boolean(current?.id),
		staleTime: 3e5
	});
	(0, import_react.useEffect)(() => {
		if (related.data) appendRelated(related.data);
	}, [appendRelated, related.data]);
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerStage, { related: related.data ?? [] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDock, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueDrawer, {})
	] });
}
function PlayerStage({ related }) {
	const current = usePlayerStore((s) => s.current);
	const queue = usePlayerStore((s) => s.queue);
	const mode = usePlayerStore((s) => s.mode);
	const stageOpen = usePlayerStore((s) => s.stageOpen);
	const setStageOpen = usePlayerStore((s) => s.setStageOpen);
	const isPlaying = usePlayerStore((s) => s.isPlaying);
	const togglePlay = usePlayerStore((s) => s.togglePlay);
	if (!current || !stageOpen) return null;
	const upNext = (related.length > 0 ? related : queue.filter((t) => t.id !== current.id)).slice(0, 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative mb-8 rise-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: mode === "music" ? "Mode musik · hemat data" : "Mode video"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: () => setStageOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" }), "Ciutkan"]
			})]
		}), mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-player-slot": "stage-video",
				className: "aspect-video w-full overflow-hidden rounded-2xl bg-ink shadow-[var(--shadow-border)]"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden min-h-0 lg:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-medium",
					children: "Berikutnya"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[28rem] space-y-1 overflow-y-auto pr-1",
					children: upNext.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
						track,
						queue: upNext,
						layout: "row",
						index
					}, track.id))
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-6 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: togglePlay,
					className: "relative",
					"aria-label": isPlaying ? "Jeda" : "Putar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"data-player-slot": "stage-music",
						className: "size-[min(72vw,380px)] overflow-hidden rounded-[28px] bg-secondary shadow-[var(--shadow-lift)]"
					}), !isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute inset-0 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-16 place-items-center rounded-full bg-primary text-primary-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-7 fill-current ml-0.5" })
						})
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl leading-snug tracking-tight italic",
						children: current.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: current.channel
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeekBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, { large: true })]
				})
			]
		})]
	});
}
function PlayerDock() {
	const current = usePlayerStore((s) => s.current);
	const isPlaying = usePlayerStore((s) => s.isPlaying);
	const togglePlay = usePlayerStore((s) => s.togglePlay);
	const stageOpen = usePlayerStore((s) => s.stageOpen);
	const setStageOpen = usePlayerStore((s) => s.setStageOpen);
	const queueOpen = usePlayerStore((s) => s.queueOpen);
	const setQueueOpen = usePlayerStore((s) => s.setQueueOpen);
	const liked = usePlayerStore((s) => s.current ? s.isLiked(s.current.id) : false);
	const toggleLike = usePlayerStore((s) => s.toggleLike);
	const mode = usePlayerStore((s) => s.mode);
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!stageOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-player-slot": "pip",
		className: "pointer-events-none fixed right-4 bottom-24 z-20 size-[200px] overflow-hidden rounded-2xl opacity-0"
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 bottom-0 z-40 px-3 pb-[calc(12px+env(safe-area-inset-bottom))] sm:px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto mx-auto max-w-6xl rounded-2xl bg-card/95 p-2 shadow-[var(--shadow-border),var(--shadow-lift)] backdrop-blur-md sm:p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-w-0 flex-1 items-center gap-3 text-left",
						onClick: () => setStageOpen(!stageOpen),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: current.thumbnail,
							alt: "",
							className: "size-12 rounded-lg object-cover sm:size-14"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium",
								children: current.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted-foreground",
								children: current.channel
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden min-w-0 flex-[1.2] flex-col sm:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeekBar, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-0.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "size-10",
								"aria-label": liked ? "Hapus dari disukai" : "Sukai",
								onClick: () => toggleLike(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", liked && "fill-current text-destructive") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "size-11 sm:hidden",
								"aria-label": isPlaying ? "Jeda" : "Putar",
								onClick: togglePlay,
								children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current ml-0.5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "hidden size-10 md:inline-flex",
								"aria-label": queueOpen ? "Tutup antrian" : "Buka antrian",
								onClick: () => setQueueOpen(!queueOpen),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListMusic, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeControl, {})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 hidden px-1 text-[11px] text-muted-foreground sm:block",
				children: mode === "music" ? "Kualitas rendah untuk hemat kuota" : "Video penuh"
			})]
		})
	})] });
}
function Transport({ large = false }) {
	const isPlaying = usePlayerStore((s) => s.isPlaying);
	const togglePlay = usePlayerStore((s) => s.togglePlay);
	const next = usePlayerStore((s) => s.next);
	const prev = usePlayerStore((s) => s.prev);
	const shuffle = usePlayerStore((s) => s.shuffle);
	const toggleShuffle = usePlayerStore((s) => s.toggleShuffle);
	const repeat = usePlayerStore((s) => s.repeat);
	const cycleRepeat = usePlayerStore((s) => s.cycleRepeat);
	const RepeatIcon = repeat === "one" ? Repeat1 : Repeat;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center justify-center gap-1", large && "gap-2"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: cn("size-10", shuffle && "text-primary"),
				"aria-label": "Acak",
				"aria-pressed": shuffle,
				onClick: toggleShuffle,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-10",
				"aria-label": "Sebelumnya",
				onClick: prev,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-4 fill-current" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "default",
				size: "icon",
				className: cn("size-11", large && "size-14"),
				"aria-label": isPlaying ? "Jeda" : "Putar",
				onClick: togglePlay,
				children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: cn("size-5 fill-current", large && "size-6") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: cn("size-5 fill-current ml-0.5", large && "size-6") })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-10",
				"aria-label": "Berikutnya",
				onClick: next,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-4 fill-current" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: cn("size-10", repeat !== "off" && "text-primary"),
				"aria-label": repeatLabel(repeat),
				onClick: cycleRepeat,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RepeatIcon, { className: "size-4" })
			})
		]
	});
}
function SeekBar() {
	const currentTime = usePlayerStore((s) => s.currentTime);
	const duration = usePlayerStore((s) => s.duration);
	const seek = usePlayerStore((s) => s.seek);
	const max = duration > 0 ? duration : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 px-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-9 text-right text-[11px] tabular-nums text-muted-foreground",
				children: formatTime(currentTime)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				min: 0,
				max: max || 1,
				step: .5,
				value: [Math.min(currentTime, max)],
				onValueChange: (value) => seek(value[0] ?? 0),
				"aria-label": "Posisi lagu",
				disabled: max <= 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-9 text-[11px] tabular-nums text-muted-foreground",
				children: formatTime(max)
			})
		]
	});
}
function VolumeControl() {
	const volume = usePlayerStore((s) => s.volume);
	const muted = usePlayerStore((s) => s.muted);
	const setVolume = usePlayerStore((s) => s.setVolume);
	const toggleMute = usePlayerStore((s) => s.toggleMute);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden items-center gap-1 lg:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			size: "icon",
			className: "size-10",
			"aria-label": muted ? "Bunyi" : "Bisukan",
			onClick: toggleMute,
			children: muted || volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			className: "w-24",
			min: 0,
			max: 1,
			step: .01,
			value: [muted ? 0 : volume],
			onValueChange: (value) => setVolume(value[0] ?? 0),
			"aria-label": "Volume"
		})]
	});
}
function QueueDrawer() {
	const queueOpen = usePlayerStore((s) => s.queueOpen);
	const setQueueOpen = usePlayerStore((s) => s.setQueueOpen);
	const queue = usePlayerStore((s) => s.queue);
	const queueIndex = usePlayerStore((s) => s.queueIndex);
	const playAt = usePlayerStore((s) => s.playAt);
	if (!queueOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50",
		role: "dialog",
		"aria-label": "Antrian",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-ink/50",
			"aria-label": "Tutup antrian",
			onClick: () => setQueueOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-card shadow-[var(--shadow-lift)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-medium",
					children: ["Antrian · ", queue.length]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					className: "size-10",
					onClick: () => setQueueOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto p-2",
				children: queue.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => playAt(index),
					className: cn("flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-accent", index === queueIndex && "bg-accent"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: track.thumbnail,
							alt: "",
							className: "size-12 rounded-md object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm",
								children: track.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted-foreground",
								children: track.channel
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] tabular-nums text-muted-foreground",
							children: track.durationLabel
						})
					]
				}, `${track.id}-${index}`))
			})]
		})]
	});
}
function repeatLabel(repeat) {
	if (repeat === "one") return "Ulangi satu lagu";
	if (repeat === "all") return "Ulangi antrian";
	return "Ulangi mati";
}
var loading = null;
function loadYouTubeAPI() {
	if (typeof window === "undefined") return Promise.reject(/* @__PURE__ */ new Error("YouTube API hanya tersedia di browser"));
	if (window.YT?.Player) return Promise.resolve(window.YT);
	if (loading) return loading;
	loading = new Promise((resolve, reject) => {
		const finish = () => {
			if (window.YT?.Player) resolve(window.YT);
			else reject(/* @__PURE__ */ new Error("YouTube API gagal dimuat"));
		};
		const previous = window.onYouTubeIframeAPIReady;
		window.onYouTubeIframeAPIReady = () => {
			previous?.();
			finish();
		};
		if (!document.querySelector("script[src=\"https://www.youtube.com/iframe_api\"]")) {
			const script = document.createElement("script");
			script.src = "https://www.youtube.com/iframe_api";
			script.async = true;
			script.onerror = () => reject(/* @__PURE__ */ new Error("YouTube API gagal dimuat"));
			document.head.appendChild(script);
		}
		window.setTimeout(() => {
			if (window.YT?.Player) finish();
		}, 1e4);
	});
	return loading;
}
var YT_STATE = {
	UNSTARTED: -1,
	ENDED: 0,
	PLAYING: 1,
	PAUSED: 2,
	BUFFERING: 3,
	CUED: 5
};
function PlayerEngine() {
	const hostRef = (0, import_react.useRef)(null);
	const playerElRef = (0, import_react.useRef)(null);
	const playerRef = (0, import_react.useRef)(null);
	const pollRef = (0, import_react.useRef)(0);
	const currentId = usePlayerStore((s) => s.current?.id);
	const mode = usePlayerStore((s) => s.mode);
	const stageOpen = usePlayerStore((s) => s.stageOpen);
	(0, import_react.useEffect)(() => {
		const host = hostRef.current;
		if (!host) return;
		const sync = () => {
			const slotName = !currentId ? null : stageOpen ? mode === "video" ? "stage-video" : "stage-music" : "pip";
			const slot = slotName ? document.querySelector(`[data-player-slot="${slotName}"]`) : null;
			if (!slot || !currentId) {
				host.style.opacity = "0";
				host.style.pointerEvents = "none";
				return;
			}
			const rect = slot.getBoundingClientRect();
			if (rect.width < 8 || rect.height < 8) {
				host.style.opacity = "0";
				return;
			}
			host.style.opacity = !stageOpen && mode === "music" ? "0.06" : "1";
			host.style.pointerEvents = stageOpen ? "auto" : "none";
			host.style.top = `${rect.top}px`;
			host.style.left = `${rect.left}px`;
			host.style.width = `${rect.width}px`;
			host.style.height = `${rect.height}px`;
			host.style.borderRadius = getComputedStyle(slot).borderRadius;
			try {
				playerRef.current?.setSize(Math.max(200, Math.round(rect.width)), Math.max(200, Math.round(rect.height)));
			} catch {}
		};
		sync();
		const observer = new ResizeObserver(sync);
		observer.observe(document.documentElement);
		window.addEventListener("resize", sync);
		window.addEventListener("scroll", sync, true);
		const interval = window.setInterval(sync, 200);
		return () => {
			observer.disconnect();
			window.removeEventListener("resize", sync);
			window.removeEventListener("scroll", sync, true);
			window.clearInterval(interval);
		};
	}, [
		currentId,
		mode,
		stageOpen
	]);
	(0, import_react.useEffect)(() => {
		if (!currentId) return;
		let cancelled = false;
		const applyQuality = (player) => {
			const music = usePlayerStore.getState().mode === "music";
			try {
				player.setPlaybackQuality(music ? "tiny" : "large");
			} catch {}
		};
		const startPoll = (player) => {
			if (pollRef.current) return;
			pollRef.current = window.setInterval(() => {
				try {
					const t = player.getCurrentTime();
					const d = player.getDuration();
					if (Number.isFinite(t) && Number.isFinite(d)) usePlayerStore.getState().setProgress(t, d || usePlayerStore.getState().duration);
				} catch {}
			}, 250);
		};
		loadYouTubeAPI().then((YT) => {
			if (cancelled || !playerElRef.current) return;
			const latestId = usePlayerStore.getState().current?.id;
			if (!latestId) return;
			if (playerRef.current) {
				playerRef.current.loadVideoById(latestId);
				applyQuality(playerRef.current);
				return;
			}
			const player = new YT.Player(playerElRef.current, {
				width: 640,
				height: 360,
				videoId: latestId,
				playerVars: {
					autoplay: 1,
					controls: 0,
					disablekb: 1,
					fs: 1,
					modestbranding: 1,
					rel: 0,
					iv_load_policy: 3,
					playsinline: 1,
					origin: window.location.origin
				},
				events: {
					onReady: (event) => {
						const store = usePlayerStore.getState();
						event.target.setVolume(Math.round(store.volume * 100));
						if (store.muted) event.target.mute();
						applyQuality(event.target);
						event.target.playVideo();
						store.setReady(true);
						store.setProgress(0, event.target.getDuration() || store.duration);
					},
					onStateChange: (event) => {
						const store = usePlayerStore.getState();
						if (event.data === YT_STATE.ENDED) store.next();
						if (event.data === YT_STATE.PLAYING) {
							store.setPlaying(true);
							applyQuality(event.target);
							const duration = event.target.getDuration();
							if (duration) store.setProgress(event.target.getCurrentTime(), duration);
						}
						if (event.data === YT_STATE.PAUSED) store.setPlaying(false);
					},
					onError: () => {
						toast.error("Video ini tidak bisa diputar. Melanjutkan ke berikutnya.");
						window.setTimeout(() => usePlayerStore.getState().next(), 400);
					}
				}
			});
			playerRef.current = player;
			bindPlayerEngine({
				play: () => player.playVideo(),
				pause: () => player.pauseVideo(),
				seekTo: (seconds) => player.seekTo(seconds, true),
				setVolume: (v) => player.setVolume(Math.round(v * 100)),
				mute: () => player.mute(),
				unMute: () => player.unMute(),
				load: (id) => player.loadVideoById(id),
				setMusicQuality: (on) => {
					try {
						player.setPlaybackQuality(on ? "tiny" : "large");
					} catch {}
				}
			});
			startPoll(player);
		}).catch((error) => {
			const message = error instanceof Error ? error.message : "Pemutar gagal dimuat";
			toast.error(message);
		});
		return () => {
			cancelled = true;
		};
	}, [currentId]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (pollRef.current) window.clearInterval(pollRef.current);
			bindPlayerEngine(null);
			playerRef.current?.destroy();
			playerRef.current = null;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: hostRef,
		className: cn("pointer-events-none fixed z-30 overflow-hidden bg-ink shadow-[var(--shadow-lift)] transition-opacity duration-200", !currentId && "hidden"),
		style: { opacity: 0 },
		"aria-hidden": !stageOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: playerElRef,
			className: "size-full"
		})
	});
}
function AppShell() {
	const hasTrack = usePlayerStore((s) => Boolean(s.current));
	(0, import_react.useEffect)(() => {
		Promise.resolve(usePlayerStore.persist.rehydrate()).then(() => {
			usePlayerStore.getState().setHydrated();
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
			const store = usePlayerStore.getState();
			if (!store.current) return;
			if (event.code === "Space") {
				event.preventDefault();
				store.togglePlay();
			} else if (event.code === "ArrowRight") store.seek(store.currentTime + 5);
			else if (event.code === "ArrowLeft") store.seek(Math.max(0, store.currentTime - 5));
			else if (event.key === "n" || event.key === "N") store.next();
			else if (event.key === "p" || event.key === "P") store.prev();
			else if (event.key === "m" || event.key === "M") store.toggleMute();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const current = usePlayerStore((s) => s.current);
	(0, import_react.useEffect)(() => {
		if (!current || !("mediaSession" in navigator)) return;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: current.title,
			artist: current.channel,
			artwork: [{
				src: current.thumbnail,
				sizes: "320x180",
				type: "image/jpeg"
			}]
		});
		navigator.mediaSession.setActionHandler("play", () => {
			const store = usePlayerStore.getState();
			if (!store.isPlaying) store.togglePlay();
		});
		navigator.mediaSession.setActionHandler("pause", () => {
			const store = usePlayerStore.getState();
			if (store.isPlaying) store.togglePlay();
		});
		navigator.mediaSession.setActionHandler("previoustrack", () => {
			usePlayerStore.getState().prev();
		});
		navigator.mediaSession.setActionHandler("nexttrack", () => {
			usePlayerStore.getState().next();
		});
	}, [current]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: cn("mx-auto max-w-6xl px-4 pt-6 sm:px-6", hasTrack ? "pb-36" : "pb-16"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerChrome, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogTabs, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Catalog, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerEngine, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
