import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-BhS6FQuj.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatTime(totalSeconds) {
	if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return "0:00";
	const seconds = Math.floor(totalSeconds);
	const h = Math.floor(seconds / 3600);
	const m = Math.floor(seconds % 3600 / 60);
	const s = seconds % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function parseDurationLabel(label) {
	if (!label) return {
		display: "",
		seconds: 0
	};
	const raw = label.trim();
	if (!raw) return {
		display: "",
		seconds: 0
	};
	const parts = raw.split(/[:.]/).map((part) => Number(part));
	if (parts.length < 2 || parts.some((n) => Number.isNaN(n))) return {
		display: raw,
		seconds: 0
	};
	let seconds = 0;
	if (parts.length === 3) seconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
	else seconds = parts[0] * 60 + parts[1];
	return {
		display: formatTime(seconds),
		seconds
	};
}
function extractYoutubeId(input) {
	const trimmed = input.trim();
	if (/^[\w-]{11}$/.test(trimmed)) return trimmed;
	try {
		const url = new URL(trimmed);
		const host = url.hostname.replace(/^www\./, "");
		if (host === "youtu.be") {
			const id = url.pathname.split("/").filter(Boolean)[0];
			return id && /^[\w-]{11}$/.test(id) ? id : null;
		}
		if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
			const v = url.searchParams.get("v");
			if (v && /^[\w-]{11}$/.test(v)) return v;
			const parts = url.pathname.split("/").filter(Boolean);
			const marker = parts.findIndex((p) => p === "shorts" || p === "embed" || p === "live");
			if (marker >= 0) {
				const id = parts[marker + 1];
				if (id && /^[\w-]{11}$/.test(id)) return id;
			}
		}
	} catch {
		return null;
	}
	return null;
}
function greetingId(date = /* @__PURE__ */ new Date()) {
	const h = date.getHours();
	if (h < 11) return "Selamat pagi";
	if (h < 15) return "Selamat siang";
	if (h < 18) return "Selamat sore";
	return "Selamat malam";
}
//#endregion
export { parseDurationLabel as a, greetingId as i, extractYoutubeId as n, formatTime as r, cn as t };
