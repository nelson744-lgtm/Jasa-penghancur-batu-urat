import { a as parseDurationLabel } from "./utils-BhS6FQuj.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/youtube-DM1si5Y3.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var HOME_SECTIONS = [
	{
		id: "indo",
		title: "Hits Indonesia",
		subtitle: "Yang ramai diputar minggu ini",
		query: "lagu pop indonesia terbaru official"
	},
	{
		id: "global",
		title: "Pop global",
		subtitle: "Tangga lagu internasional",
		query: "top pop hits official audio"
	},
	{
		id: "lofi",
		title: "Fokus",
		subtitle: "Lofi dan instrumen tenang",
		query: "lofi hip hop mix"
	},
	{
		id: "acoustic",
		title: "Akustik",
		subtitle: "Gitar, piano, suara telanjang",
		query: "acoustic cover songs"
	}
];
var INNERTUBE_URL = "https://www.youtube.com/youtubei/v1";
var CLIENT_VERSION = "2.20240620.00.00";
function innertubeContext() {
	return { client: {
		clientName: "WEB",
		clientVersion: CLIENT_VERSION,
		hl: "id",
		gl: "ID"
	} };
}
async function innertube(endpoint, body) {
	const response = await fetch(`${INNERTUBE_URL}/${endpoint}?prettyPrint=false`, {
		method: "POST",
		headers: {
			"content-type": "application/json",
			"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
			"x-youtube-client-name": "1",
			"x-youtube-client-version": CLIENT_VERSION,
			origin: "https://www.youtube.com"
		},
		body: JSON.stringify({
			context: innertubeContext(),
			...body
		})
	});
	if (!response.ok) throw new Error(`YouTube ${endpoint} gagal (${response.status})`);
	return await response.json();
}
function asRecord(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return null;
}
function textOf(value) {
	if (typeof value === "string") return value;
	const rec = asRecord(value);
	if (!rec) return "";
	if (typeof rec.simpleText === "string") return rec.simpleText;
	if (typeof rec.content === "string") return rec.content;
	if (Array.isArray(rec.runs)) return rec.runs.map((run) => {
		const r = asRecord(run);
		return r && typeof r.text === "string" ? r.text : "";
	}).join("");
	return "";
}
function walkCollect(root, key) {
	const found = [];
	const visit = (node) => {
		if (!node || typeof node !== "object") return;
		if (Array.isArray(node)) {
			for (const item of node) visit(item);
			return;
		}
		const rec = node;
		if (key in rec) found.push(rec[key]);
		for (const value of Object.values(rec)) visit(value);
	};
	visit(root);
	return found;
}
function thumbnailFrom(value) {
	const rec = asRecord(value);
	if (!rec) return "";
	const thumbs = rec.thumbnails;
	if (Array.isArray(thumbs) && thumbs.length > 0) {
		const last = asRecord(thumbs[thumbs.length - 1]);
		if (last && typeof last.url === "string") return last.url;
	}
	const sources = asRecord(rec.image)?.sources;
	if (Array.isArray(sources) && sources.length > 0) {
		const last = asRecord(sources[sources.length - 1]);
		if (last && typeof last.url === "string") return last.url;
	}
	return "";
}
function idFromThumb(url) {
	return url.match(/\/vi\/([\w-]{11})\//)?.[1] ?? null;
}
function trackFromVideoRenderer(raw) {
	const rec = asRecord(raw);
	if (!rec) return null;
	const id = typeof rec.videoId === "string" ? rec.videoId : null;
	if (!id || !/^[\w-]{11}$/.test(id)) return null;
	const title = textOf(rec.title).trim();
	if (!title) return null;
	const channel = textOf(rec.ownerText) || textOf(rec.shortBylineText);
	const durationRaw = textOf(rec.lengthText);
	if (!durationRaw) return null;
	const duration = parseDurationLabel(durationRaw);
	const thumb = thumbnailFrom(rec.thumbnail) || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
	return {
		id,
		title,
		channel: channel || "YouTube",
		thumbnail: thumb,
		durationLabel: duration.display || durationRaw,
		durationSeconds: duration.seconds,
		views: textOf(rec.shortViewCountText) || textOf(rec.viewCountText) || void 0,
		published: textOf(rec.publishedTimeText) || void 0
	};
}
function nested(obj, path) {
	let current = obj;
	for (const key of path) {
		const rec = asRecord(current);
		if (!rec) return void 0;
		current = rec[key];
	}
	return current;
}
function trackFromLockup(raw) {
	const rec = asRecord(raw);
	if (!rec) return null;
	const contentType = typeof rec.contentType === "string" ? rec.contentType : "";
	if (contentType && !contentType.includes("VIDEO") && contentType.includes("PLAYLIST")) return null;
	const thumb = thumbnailFrom(nested(rec, ["contentImage", "thumbnailViewModel"])) || thumbnailFrom(nested(rec, [
		"contentImage",
		"thumbnailViewModel",
		"image"
	]));
	const id = (typeof rec.contentId === "string" && /^[\w-]{11}$/.test(rec.contentId) ? rec.contentId : null) || idFromThumb(thumb);
	if (!id) return null;
	const title = textOf(nested(rec, [
		"metadata",
		"lockupMetadataViewModel",
		"title"
	])).trim();
	if (!title) return null;
	const channel = textOf(nested(rec, [
		"metadata",
		"lockupMetadataViewModel",
		"metadata",
		"contentMetadataViewModel",
		"metadataRows"
	])) || "";
	const rows = nested(rec, [
		"metadata",
		"lockupMetadataViewModel",
		"metadata",
		"contentMetadataViewModel",
		"metadataRows"
	]);
	let channelName = "";
	let views;
	let published;
	if (Array.isArray(rows)) {
		const row0 = asRecord(rows[0]);
		channelName = textOf(asRecord((row0 && Array.isArray(row0.metadataParts) ? row0.metadataParts : [])[0])?.text);
		const row1 = asRecord(rows[1]);
		const parts1 = row1 && Array.isArray(row1.metadataParts) ? row1.metadataParts : [];
		views = textOf(asRecord(parts1[0])?.text) || void 0;
		published = textOf(asRecord(parts1[1])?.text) || void 0;
	}
	const overlays = nested(rec, [
		"contentImage",
		"thumbnailViewModel",
		"overlays"
	]);
	let durationRaw = "";
	const visitBadges = (node) => {
		if (durationRaw || !node || typeof node !== "object") return;
		if (Array.isArray(node)) {
			for (const item of node) visitBadges(item);
			return;
		}
		const r = node;
		if (r.thumbnailBadgeViewModel) {
			const badge = asRecord(r.thumbnailBadgeViewModel);
			const text = badge && typeof badge.text === "string" ? badge.text : "";
			if (text && /[\d:.]/.test(text) && !/LIVE|PREMIERE/i.test(text)) {
				durationRaw = text;
				return;
			}
		}
		for (const value of Object.values(r)) visitBadges(value);
	};
	visitBadges(overlays);
	if (!durationRaw) return null;
	const duration = parseDurationLabel(durationRaw);
	return {
		id,
		title,
		channel: channelName || channel || "YouTube",
		thumbnail: thumb || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
		durationLabel: duration.display || durationRaw,
		durationSeconds: duration.seconds,
		views,
		published
	};
}
function uniqueTracks(tracks, limit = 24) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const track of tracks) {
		if (seen.has(track.id)) continue;
		seen.add(track.id);
		out.push(track);
		if (out.length >= limit) break;
	}
	return out;
}
function parseSearch(data, limit = 24) {
	const videos = walkCollect(data, "videoRenderer").map(trackFromVideoRenderer);
	const lockups = walkCollect(data, "lockupViewModel").map(trackFromLockup);
	return uniqueTracks([...videos, ...lockups].filter((t) => t !== null), limit);
}
var searchInput = object({ query: string().min(1).max(200) });
var searchYoutube_createServerFn_handler = createServerRpc({
	id: "7df3dd16e784b248b7d886a0783a467b063c331e19af46955cb1384e05116dfc",
	name: "searchYoutube",
	filename: "src/lib/youtube.ts"
}, (opts) => searchYoutube.__executeServer(opts));
var searchYoutube = createServerFn({ method: "POST" }).validator(searchInput).handler(searchYoutube_createServerFn_handler, async ({ data }) => {
	const query = data.query.trim();
	const tracks = parseSearch(await innertube("search", {
		query,
		params: "EgIQAQ=="
	}), 28);
	if (tracks.length === 0) throw new Error("Tidak ada hasil. Coba kata kunci lain.");
	return {
		query,
		tracks
	};
});
var suggestYoutube_createServerFn_handler = createServerRpc({
	id: "37b4ff33f5cc3af2ecb5f1e50e9379e7d8f1f74e87e60d09dc0dbcf2d904f880",
	name: "suggestYoutube",
	filename: "src/lib/youtube.ts"
}, (opts) => suggestYoutube.__executeServer(opts));
var suggestYoutube = createServerFn({ method: "POST" }).validator(searchInput).handler(suggestYoutube_createServerFn_handler, async ({ data }) => {
	const query = data.query.trim();
	if (query.length < 2) return [];
	const url = new URL("https://suggestqueries.google.com/complete/search");
	url.searchParams.set("client", "firefox");
	url.searchParams.set("ds", "yt");
	url.searchParams.set("hl", "id");
	url.searchParams.set("q", query);
	const response = await fetch(url, { headers: { "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36" } });
	if (!response.ok) return [];
	const json = await response.json();
	if (!Array.isArray(json) || !Array.isArray(json[1])) return [];
	return json[1].filter((item) => typeof item === "string").slice(0, 8);
});
var getRelated_createServerFn_handler = createServerRpc({
	id: "4fee74457b336958e838f0859030ebd73f452b570d87b3206d15941f82ffb01b",
	name: "getRelated",
	filename: "src/lib/youtube.ts"
}, (opts) => getRelated.__executeServer(opts));
var getRelated = createServerFn({ method: "POST" }).validator(object({ videoId: string().regex(/^[\w-]{11}$/) })).handler(getRelated_createServerFn_handler, async ({ data }) => {
	return parseSearch(await innertube("next", { videoId: data.videoId }), 20).filter((t) => t.id !== data.videoId);
});
var resolveVideo_createServerFn_handler = createServerRpc({
	id: "12de13b4b588c7ab1a8151c83501d7cadeddf5ae6d69fb6dd149fcd90514d7de",
	name: "resolveVideo",
	filename: "src/lib/youtube.ts"
}, (opts) => resolveVideo.__executeServer(opts));
var resolveVideo = createServerFn({ method: "POST" }).validator(object({ videoId: string().regex(/^[\w-]{11}$/) })).handler(resolveVideo_createServerFn_handler, async ({ data }) => {
	const oembedUrl = new URL("https://www.youtube.com/oembed");
	oembedUrl.searchParams.set("url", `https://www.youtube.com/watch?v=${data.videoId}`);
	oembedUrl.searchParams.set("format", "json");
	const response = await fetch(oembedUrl);
	if (!response.ok) throw new Error("Video tidak ditemukan.");
	const json = await response.json();
	return {
		id: data.videoId,
		title: json.title?.trim() || "YouTube",
		channel: json.author_name?.trim() || "YouTube",
		thumbnail: json.thumbnail_url || `https://i.ytimg.com/vi/${data.videoId}/hqdefault.jpg`,
		durationLabel: "",
		durationSeconds: 0
	};
});
var homeCache = null;
var HOME_TTL_MS = 3e5;
var getHomeFeed_createServerFn_handler = createServerRpc({
	id: "a5694f4614a0cb2612bc92a0a839d3a7320fa9c0d85e1190a757f45efb7dc567",
	name: "getHomeFeed",
	filename: "src/lib/youtube.ts"
}, (opts) => getHomeFeed.__executeServer(opts));
var getHomeFeed = createServerFn({ method: "GET" }).handler(getHomeFeed_createServerFn_handler, async () => {
	if (homeCache && Date.now() - homeCache.at < HOME_TTL_MS) return homeCache.sections;
	const settled = await Promise.allSettled(HOME_SECTIONS.map(async (section) => {
		const json = await innertube("search", {
			query: section.query,
			params: "EgIQAQ=="
		});
		return {
			id: section.id,
			title: section.title,
			subtitle: section.subtitle,
			tracks: parseSearch(json, 12)
		};
	}));
	const sections = [];
	for (const item of settled) if (item.status === "fulfilled" && item.value.tracks.length > 0) sections.push(item.value);
	if (sections.length === 0) throw new Error("Gagal memuat katalog. Coba lagi sebentar.");
	homeCache = {
		at: Date.now(),
		sections
	};
	return sections;
});
//#endregion
export { getHomeFeed_createServerFn_handler, getRelated_createServerFn_handler, resolveVideo_createServerFn_handler, searchYoutube_createServerFn_handler, suggestYoutube_createServerFn_handler };
