import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { getHomeFeed, type HomeSection } from "@/lib/youtube";

type HomeSearch = {
  q?: string;
  tab?: "likes" | "history";
};

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): HomeSearch => {
    const q = typeof search.q === "string" ? search.q : undefined;
    const tab = search.tab === "likes" || search.tab === "history" ? search.tab : undefined;
    return { q, tab };
  },
  loaderDeps: ({ search }) => ({ q: search.q }),
  loader: async ({ deps }): Promise<{ sections: HomeSection[] | null }> => {
    if (deps.q) return { sections: null };
    try {
      return { sections: await getHomeFeed() };
    } catch {
      return { sections: null };
    }
  },
  component: Home,
});

function Home() {
  return <AppShell />;
}
