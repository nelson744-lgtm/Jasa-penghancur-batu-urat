import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { Track } from "@/lib/youtube";

export type PlayMode = "music" | "video";
export type RepeatMode = "off" | "one" | "all";

export type PlayerEngine = {
  play: () => void;
  pause: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (volume01: number) => void;
  mute: () => void;
  unMute: () => void;
  load: (videoId: string) => void;
  setMusicQuality: (on: boolean) => void;
};

let engine: PlayerEngine | null = null;

export function bindPlayerEngine(next: PlayerEngine | null) {
  engine = next;
}

type PlayerState = {
  mode: PlayMode;
  current: Track | null;
  queue: Track[];
  queueIndex: number;
  isPlaying: boolean;
  isReady: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  likes: Track[];
  history: Track[];
  stageOpen: boolean;
  queueOpen: boolean;
  hydrated: boolean;

  setHydrated: () => void;
  setMode: (mode: PlayMode) => void;
  setReady: (ready: boolean) => void;
  setProgress: (currentTime: number, duration: number) => void;
  setPlaying: (playing: boolean) => void;
  playTrack: (track: Track, queue?: Track[]) => void;
  playAt: (index: number) => void;
  togglePlay: () => void;
  next: () => void;
  prev: () => void;
  seek: (seconds: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  toggleLike: (track?: Track) => void;
  isLiked: (id: string) => boolean;
  addToQueue: (track: Track) => void;
  removeFromQueue: (index: number) => void;
  setStageOpen: (open: boolean) => void;
  setQueueOpen: (open: boolean) => void;
  appendRelated: (tracks: Track[]) => void;
};

function remember(history: Track[], track: Track): Track[] {
  return [track, ...history.filter((item) => item.id !== track.id)].slice(0, 40);
}

export const usePlayerStore = create<PlayerState>()(
  persist(
    (set, get) => ({
      mode: "music",
      current: null,
      queue: [],
      queueIndex: 0,
      isPlaying: false,
      isReady: false,
      currentTime: 0,
      duration: 0,
      volume: 0.8,
      muted: false,
      shuffle: false,
      repeat: "off",
      likes: [],
      history: [],
      stageOpen: false,
      queueOpen: false,
      hydrated: false,

      setHydrated: () => set({ hydrated: true }),
      setMode: (mode) => {
        set({ mode, stageOpen: true });
        engine?.setMusicQuality(mode === "music");
      },
      setReady: (isReady) => set({ isReady }),
      setProgress: (currentTime, duration) => set({ currentTime, duration }),
      setPlaying: (isPlaying) => set({ isPlaying }),

      playTrack: (track, list) => {
        const queue = list && list.length > 0 ? uniqueQueue(list, track) : [track];
        const queueIndex = Math.max(
          0,
          queue.findIndex((item) => item.id === track.id),
        );
        set({
          current: track,
          queue,
          queueIndex,
          isPlaying: true,
          currentTime: 0,
          duration: track.durationSeconds || 0,
          stageOpen: true,
          history: remember(get().history, track),
        });
        engine?.load(track.id);
      },

      playAt: (index) => {
        const { queue } = get();
        const track = queue[index];
        if (!track) return;
        set({
          current: track,
          queueIndex: index,
          isPlaying: true,
          currentTime: 0,
          duration: track.durationSeconds || 0,
          history: remember(get().history, track),
        });
        engine?.load(track.id);
      },

      togglePlay: () => {
        const { current, isPlaying } = get();
        if (!current) return;
        if (isPlaying) {
          engine?.pause();
          set({ isPlaying: false });
        } else {
          engine?.play();
          set({ isPlaying: true });
        }
      },

      next: () => {
        const { repeat, shuffle, queueIndex, queue, current } = get();
        if (!current) return;
        if (repeat === "one") {
          engine?.seekTo(0);
          engine?.play();
          set({ isPlaying: true, currentTime: 0 });
          return;
        }
        if (shuffle && queue.length > 1) {
          const others = queue.map((_, i) => i).filter((i) => i !== queueIndex);
          const pick = others[Math.floor(Math.random() * others.length)] ?? 0;
          get().playAt(pick);
          return;
        }
        const nextIndex = queueIndex + 1;
        if (nextIndex < queue.length) {
          get().playAt(nextIndex);
          return;
        }
        if (repeat === "all" && queue.length > 0) {
          get().playAt(0);
          return;
        }
        engine?.pause();
        set({ isPlaying: false });
      },

      prev: () => {
        const { currentTime, queueIndex, queue } = get();
        if (currentTime > 3 || queueIndex <= 0) {
          engine?.seekTo(0);
          set({ currentTime: 0, isPlaying: true });
          engine?.play();
          return;
        }
        const prev = queue[queueIndex - 1];
        if (prev) get().playAt(queueIndex - 1);
      },

      seek: (seconds) => {
        engine?.seekTo(seconds);
        set({ currentTime: seconds });
      },

      setVolume: (volume) => {
        const next = Math.min(1, Math.max(0, volume));
        set({ volume: next, muted: next === 0 });
        engine?.setVolume(next);
        if (next === 0) engine?.mute();
        else engine?.unMute();
      },

      toggleMute: () => {
        const { muted, volume } = get();
        if (muted) {
          engine?.unMute();
          engine?.setVolume(volume || 0.8);
          set({ muted: false, volume: volume || 0.8 });
        } else {
          engine?.mute();
          set({ muted: true });
        }
      },

      toggleShuffle: () => set({ shuffle: !get().shuffle }),
      cycleRepeat: () => {
        const order: RepeatMode[] = ["off", "all", "one"];
        const current = get().repeat;
        const next = order[(order.indexOf(current) + 1) % order.length] ?? "off";
        set({ repeat: next });
      },

      toggleLike: (track) => {
        const target = track ?? get().current;
        if (!target) return;
        const { likes } = get();
        const exists = likes.some((item) => item.id === target.id);
        set({
          likes: exists
            ? likes.filter((item) => item.id !== target.id)
            : [target, ...likes].slice(0, 100),
        });
      },

      isLiked: (id) => get().likes.some((item) => item.id === id),

      addToQueue: (track) => {
        const { queue, current } = get();
        if (queue.some((item) => item.id === track.id)) return;
        if (!current) {
          get().playTrack(track);
          return;
        }
        set({ queue: [...queue, track] });
      },

      removeFromQueue: (index) => {
        const { queue, queueIndex } = get();
        if (index === queueIndex) return;
        const nextQueue = queue.filter((_, i) => i !== index);
        const nextIndex = index < queueIndex ? queueIndex - 1 : queueIndex;
        set({ queue: nextQueue, queueIndex: nextIndex });
      },

      setStageOpen: (stageOpen) => set({ stageOpen }),
      setQueueOpen: (queueOpen) => set({ queueOpen }),

      appendRelated: (tracks) => {
        const { queue, current } = get();
        if (!current || tracks.length === 0) return;
        if (queue.length > 1) return;
        const extra = tracks.filter(
          (track) => track.id !== current.id && !queue.some((item) => item.id === track.id),
        );
        if (extra.length === 0) return;
        set({ queue: [...queue, ...extra] });
      },
    }),
    {
      name: "nada-player-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        mode: state.mode,
        volume: state.volume,
        muted: state.muted,
        shuffle: state.shuffle,
        repeat: state.repeat,
        likes: state.likes,
        history: state.history,
      }),
    },
  ),
);

function uniqueQueue(list: Track[], first: Track): Track[] {
  const rest = list.filter((item) => item.id !== first.id);
  return [first, ...rest];
}
