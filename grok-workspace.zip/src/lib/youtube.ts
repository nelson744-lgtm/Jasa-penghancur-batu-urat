import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { parseDurationLabel } from "@/lib/utils";

export type Track = {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  durationLabel: string;
  durationSeconds: number;
  views?: string;
  published?: string;
};

export type HomeSection = {
  id: string;
  title: string;
  subtitle: string;
  tracks: Track[];
};

export const HOME_SECTIONS = [
  {
    id: "indo",
    title: "Hits Indonesia",
    subtitle: "Yang ramai diputar minggu ini",
    query: "lagu pop indonesia terbaru official",
  },
  {
    id: "global",
    title: "Pop global",
    subtitle: "Tangga lagu internasional",
    query: "top pop hits official audio",
  },
  {
    id: "lofi",
    title: "Fokus",
    subtitle: "Lofi dan instrumen tenang",
    query: "lofi hip hop mix",
  },
  {
    id: "acoustic",
    title: "Akustik",
    subtitle: "Gitar, piano, suara telanjang",
    query: "acoustic cover songs",
  },
] as const;

const INNERTUBE_URL = "https://www.youtube.com/youtubei/v1";
const CLIENT_VERSION = "2.20240620.00.00";

function innertubeContext() {
  return {
    client: {
      clientName: "WEB" as const,
      clientVersion: CLIENT_VERSION,
      hl: "id",
      gl: "ID",
    },
  };
}

async function innertube(endpoint: string, body: Record<string, unknown>) {
  const response = await fetch(`${INNERTUBE_URL}/${endpoint}?prettyPrint=false`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
      "x-youtube-client-name": "1",
      "x-youtube-client-version": CLIENT_VERSION,
      origin: "https://www.youtube.com",
    },
    body: JSON.stringify({ context: innertubeContext(), ...body }),
  });
  if (!response.ok) {
    throw new Error(`YouTube ${endpoint} gagal (${response.status})`);
  }
  return (await response.json()) as unknown;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return null;
}

function textOf(value: unknown): string {
  if (typeof value === "string") return value;
  const rec = asRecord(value);
  if (!rec) return "";
  if (typeof rec.simpleText === "string") return rec.simpleText;
  if (typeof rec.content === "string") return rec.content;
  if (Array.isArray(rec.runs)) {
    return rec.runs
      .map((run) => {
        const r = asRecord(run);
        return r && typeof r.text === "string" ? r.text : "";
      })
      .join("");
  }
  return "";
}

function walkCollect(root: unknown, key: string): unknown[] {
  const found: unknown[] = [];
  const visit = (node: unknown) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const item of node) visit(item);
      return;
    }
    const rec = node as Record<string, unknown>;
    if (key in rec) found.push(rec[key]);
    for (const value of Object.values(rec)) visit(value);
  };
  visit(root);
  return found;
}

function thumbnailFrom(value: unknown): string {
  const rec = asRecord(value);
  if (!rec) return "";
  const thumbs = rec.thumbnails;
  if (Array.isArray(thumbs) && thumbs.length > 0) {
    const last = asRecord(thumbs[thumbs.length - 1]);
    if (last && typeof last.url === "string") return last.url;
  }
  const image = asRecord(rec.image);
  const sources = image?.sources;
  if (Array.isArray(sources) && sources.length > 0) {
    const last = asRecord(sources[sources.length - 1]);
    if (last && typeof last.url === "string") return last.url;
  }
  return "";
}

function idFromThumb(url: string): string | null {
  const match = url.match(/\/vi\/([\w-]{11})\//);
  return match?.[1] ?? null;
}

function trackFromVideoRenderer(raw: unknown): Track | null {
  const rec = asRecord(raw);
  if (!rec) return null;
  const id = typeof rec.videoId === "string" ? rec.videoId : null;
  if (!id || !/^[\w-]{11}$/.test(id)) return null;
  const title = textOf(rec.title).trim();
  if (!title) return null;
  const channel = textOf(rec.ownerText) || textOf(rec.shortBylineText);
  const durationRaw = textOf(rec.lengthText);
  if (!durationRaw) return null;
  const duration = parseDurationLabel(durationRaw);
  const thumb = thumbnailFrom(rec.thumbnail) || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
  return {
    id,
    title,
    channel: channel || "YouTube",
    thumbnail: thumb,
    durationLabel: duration.display || durationRaw,
    durationSeconds: duration.seconds,
    views: textOf(rec.shortViewCountText) || textOf(rec.viewCountText) || undefined,
    published: textOf(rec.publishedTimeText) || undefined,
  };
}

function nested(obj: unknown, path: string[]): unknown {
  let current: unknown = obj;
  for (const key of path) {
    const rec = asRecord(current);
    if (!rec) return undefined;
    current = rec[key];
  }
  return current;
}

function trackFromLockup(raw: unknown): Track | null {
  const rec = asRecord(raw);
  if (!rec) return null;
  const contentType = typeof rec.contentType === "string" ? rec.contentType : "";
  if (contentType && !contentType.includes("VIDEO") && contentType.includes("PLAYLIST")) {
    return null;
  }
  const thumb =
    thumbnailFrom(nested(rec, ["contentImage", "thumbnailViewModel"])) ||
    thumbnailFrom(nested(rec, ["contentImage", "thumbnailViewModel", "image"]));
  const id =
    (typeof rec.contentId === "string" && /^[\w-]{11}$/.test(rec.contentId)
      ? rec.contentId
      : null) || idFromThumb(thumb);
  if (!id) return null;
  const title = textOf(nested(rec, ["metadata", "lockupMetadataViewModel", "title"])).trim();
  if (!title) return null;
  const channel =
    textOf(
      nested(rec, [
        "metadata",
        "lockupMetadataViewModel",
        "metadata",
        "contentMetadataViewModel",
        "metadataRows",
      ]),
    ) || "";
  const rows = nested(rec, [
    "metadata",
    "lockupMetadataViewModel",
    "metadata",
    "contentMetadataViewModel",
    "metadataRows",
  ]);
  let channelName = "";
  let views: string | undefined;
  let published: string | undefined;
  if (Array.isArray(rows)) {
    const row0 = asRecord(rows[0]);
    const parts0 = row0 && Array.isArray(row0.metadataParts) ? row0.metadataParts : [];
    channelName = textOf(asRecord(parts0[0])?.text);
    const row1 = asRecord(rows[1]);
    const parts1 = row1 && Array.isArray(row1.metadataParts) ? row1.metadataParts : [];
    views = textOf(asRecord(parts1[0])?.text) || undefined;
    published = textOf(asRecord(parts1[1])?.text) || undefined;
  }
  const overlays = nested(rec, ["contentImage", "thumbnailViewModel", "overlays"]);
  let durationRaw = "";
  const visitBadges = (node: unknown) => {
    if (durationRaw || !node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const item of node) visitBadges(item);
      return;
    }
    const r = node as Record<string, unknown>;
    if (r.thumbnailBadgeViewModel) {
      const badge = asRecord(r.thumbnailBadgeViewModel);
      const text = badge && typeof badge.text === "string" ? badge.text : "";
      if (text && /[\d:.]/.test(text) && !/LIVE|PREMIERE/i.test(text)) {
        durationRaw = text;
        return;
      }
    }
    for (const value of Object.values(r)) visitBadges(value);
  };
  visitBadges(overlays);
  if (!durationRaw) return null;
  const duration = parseDurationLabel(durationRaw);
  return {
    id,
    title,
    channel: channelName || channel || "YouTube",
    thumbnail: thumb || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    durationLabel: duration.display || durationRaw,
    durationSeconds: duration.seconds,
    views,
    published,
  };
}

function uniqueTracks(tracks: Track[], limit = 24): Track[] {
  const seen = new Set<string>();
  const out: Track[] = [];
  for (const track of tracks) {
    if (seen.has(track.id)) continue;
    seen.add(track.id);
    out.push(track);
    if (out.length >= limit) break;
  }
  return out;
}

function parseSearch(data: unknown, limit = 24): Track[] {
  const videos = walkCollect(data, "videoRenderer").map(trackFromVideoRenderer);
  const lockups = walkCollect(data, "lockupViewModel").map(trackFromLockup);
  return uniqueTracks(
    [...videos, ...lockups].filter((t): t is Track => t !== null),
    limit,
  );
}

const searchInput = z.object({
  query: z.string().min(1).max(200),
});

export const searchYoutube = createServerFn({ method: "POST" })
  .validator(searchInput)
  .handler(async ({ data }) => {
    const query = data.query.trim();
    const json = await innertube("search", {
      query,
      params: "EgIQAQ==",
    });
    const tracks = parseSearch(json, 28);
    if (tracks.length === 0) {
      throw new Error("Tidak ada hasil. Coba kata kunci lain.");
    }
    return { query, tracks };
  });

export const suggestYoutube = createServerFn({ method: "POST" })
  .validator(searchInput)
  .handler(async ({ data }) => {
    const query = data.query.trim();
    if (query.length < 2) return [] as string[];
    const url = new URL("https://suggestqueries.google.com/complete/search");
    url.searchParams.set("client", "firefox");
    url.searchParams.set("ds", "yt");
    url.searchParams.set("hl", "id");
    url.searchParams.set("q", query);
    const response = await fetch(url, {
      headers: {
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
      },
    });
    if (!response.ok) return [] as string[];
    const json = (await response.json()) as unknown;
    if (!Array.isArray(json) || !Array.isArray(json[1])) return [] as string[];
    return json[1].filter((item): item is string => typeof item === "string").slice(0, 8);
  });

export const getRelated = createServerFn({ method: "POST" })
  .validator(z.object({ videoId: z.string().regex(/^[\w-]{11}$/) }))
  .handler(async ({ data }) => {
    const json = await innertube("next", { videoId: data.videoId });
    const tracks = parseSearch(json, 20).filter((t) => t.id !== data.videoId);
    return tracks;
  });

export const resolveVideo = createServerFn({ method: "POST" })
  .validator(z.object({ videoId: z.string().regex(/^[\w-]{11}$/) }))
  .handler(async ({ data }) => {
    const oembedUrl = new URL("https://www.youtube.com/oembed");
    oembedUrl.searchParams.set("url", `https://www.youtube.com/watch?v=${data.videoId}`);
    oembedUrl.searchParams.set("format", "json");
    const response = await fetch(oembedUrl);
    if (!response.ok) {
      throw new Error("Video tidak ditemukan.");
    }
    const json = (await response.json()) as {
      title?: string;
      author_name?: string;
      thumbnail_url?: string;
    };
    const track: Track = {
      id: data.videoId,
      title: json.title?.trim() || "YouTube",
      channel: json.author_name?.trim() || "YouTube",
      thumbnail: json.thumbnail_url || `https://i.ytimg.com/vi/${data.videoId}/hqdefault.jpg`,
      durationLabel: "",
      durationSeconds: 0,
    };
    return track;
  });

let homeCache: { at: number; sections: HomeSection[] } | null = null;
const HOME_TTL_MS = 5 * 60 * 1000;

export const getHomeFeed = createServerFn({ method: "GET" }).handler(async () => {
  if (homeCache && Date.now() - homeCache.at < HOME_TTL_MS) {
    return homeCache.sections;
  }
  const settled = await Promise.allSettled(
    HOME_SECTIONS.map(async (section): Promise<HomeSection> => {
      const json = await innertube("search", {
        query: section.query,
        params: "EgIQAQ==",
      });
      return {
        id: section.id,
        title: section.title,
        subtitle: section.subtitle,
        tracks: parseSearch(json, 12),
      };
    }),
  );
  const sections: HomeSection[] = [];
  for (const item of settled) {
    if (item.status === "fulfilled" && item.value.tracks.length > 0) {
      sections.push(item.value);
    }
  }
  if (sections.length === 0) {
    throw new Error("Gagal memuat katalog. Coba lagi sebentar.");
  }
  homeCache = { at: Date.now(), sections };
  return sections;
});
