import { ListPlus, Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { usePlayerStore } from "@/lib/player-store";
import type { Track } from "@/lib/youtube";

type VideoCardProps = {
  track: Track;
  queue?: Track[];
  layout?: "rail" | "grid" | "row";
  index?: number;
};

export function VideoCard({ track, queue, layout = "grid", index = 0 }: VideoCardProps) {
  const currentId = usePlayerStore((s) => s.current?.id);
  const isPlaying = usePlayerStore((s) => s.isPlaying);
  const playTrack = usePlayerStore((s) => s.playTrack);
  const addToQueue = usePlayerStore((s) => s.addToQueue);
  const active = currentId === track.id;

  const onPlay = () => playTrack(track, queue);

  if (layout === "row") {
    return (
      <div
        className={cn(
          "group flex items-center gap-3 rounded-xl p-2 pr-3 transition-[background-color] duration-150 hover:bg-accent",
          active && "bg-accent",
        )}
        style={{ animationDelay: `calc(var(--motion-stagger) * ${Math.min(index, 12)})` }}
      >
        <button
          type="button"
          onClick={onPlay}
          className="relative size-14 shrink-0 overflow-hidden rounded-lg bg-secondary tap-press"
          aria-label={`Putar ${track.title}`}
        >
          <img
            src={track.thumbnail}
            alt=""
            className="size-full object-cover"
            loading="lazy"
          />
          <span className="absolute inset-0 grid place-items-center bg-ink/40 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
            <Play className="size-4 fill-current text-foreground" />
          </span>
        </button>
        <button type="button" onClick={onPlay} className="min-w-0 flex-1 text-left">
          <p className={cn("truncate text-sm font-medium", active && "text-primary")}>
            {track.title}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {track.channel}
            {track.durationLabel ? ` · ${track.durationLabel}` : ""}
          </p>
        </button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="size-10 shrink-0 text-muted-foreground"
          aria-label="Tambah ke antrian"
          onClick={() => {
            addToQueue(track);
            toast("Ditambahkan ke antrian");
          }}
        >
          <ListPlus className="size-4" />
        </Button>
      </div>
    );
  }

  const widthClass = layout === "rail" ? "w-[168px] shrink-0 snap-start sm:w-[200px]" : "w-full";

  return (
    <article
      className={cn("group rise-in", widthClass)}
      style={{ animationDelay: `calc(var(--motion-stagger) * ${Math.min(index, 12)})` }}
    >
      <button
        type="button"
        onClick={onPlay}
        className="relative block w-full overflow-hidden rounded-xl bg-secondary tap-press"
        aria-label={`Putar ${track.title}`}
      >
        <span className="relative block aspect-video">
          <img
            src={track.thumbnail}
            alt=""
            className="size-full object-cover transition-[transform] duration-300 ease-[var(--ease-smooth-out)] group-hover:scale-[1.03]"
            loading="lazy"
          />
          <span className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
          <span className="absolute right-2 bottom-2 rounded-md bg-ink/80 px-1.5 py-0.5 text-[11px] font-medium tabular-nums text-foreground">
            {track.durationLabel}
          </span>
          <span className="absolute inset-0 grid place-items-center opacity-0 transition-opacity duration-150 group-hover:opacity-100">
            <span className="grid size-12 place-items-center rounded-full bg-primary text-primary-foreground">
              <Play className="size-5 fill-current ml-0.5" />
            </span>
          </span>
          {active && isPlaying ? (
            <span className="absolute top-2 left-2 flex h-5 items-end gap-0.5 rounded-md bg-ink/80 px-1.5 py-1">
              <i className="eq-bar inline-block h-3 w-0.5 bg-primary" />
              <i className="eq-bar inline-block h-3 w-0.5 bg-primary [animation-delay:-0.2s]" />
              <i className="eq-bar inline-block h-3 w-0.5 bg-primary [animation-delay:-0.4s]" />
            </span>
          ) : null}
        </span>
      </button>
      <div className="mt-2.5 flex items-start gap-1">
        <button type="button" onClick={onPlay} className="min-w-0 flex-1 text-left">
          <h3 className={cn("line-clamp-2 text-sm font-medium leading-snug", active && "text-primary")}>
            {track.title}
          </h3>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">{track.channel}</p>
        </button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="size-8 shrink-0 text-muted-foreground opacity-100 sm:opacity-0 sm:group-hover:opacity-100"
          aria-label="Tambah ke antrian"
          onClick={() => {
            addToQueue(track);
            toast("Ditambahkan ke antrian");
          }}
        >
          <ListPlus className="size-4" />
        </Button>
      </div>
    </article>
  );
}
