import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { bindPlayerEngine, usePlayerStore } from "@/lib/player-store";
import { loadYouTubeAPI, YT_STATE, type YTPlayer } from "@/lib/youtube-iframe";
import { cn } from "@/lib/utils";

export function PlayerEngine() {
  const hostRef = useRef<HTMLDivElement>(null);
  const playerElRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<YTPlayer | null>(null);
  const pollRef = useRef(0);
  const failRef = useRef(0);
  const lastErrorRef = useRef(0);
  const currentId = usePlayerStore((s) => s.current?.id);
  const currentThumb = usePlayerStore((s) => s.current?.thumbnail);
  const mode = usePlayerStore((s) => s.mode);
  const stageOpen = usePlayerStore((s) => s.stageOpen);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const sync = () => {
      const slotName = !currentId
        ? null
        : stageOpen
          ? mode === "video"
            ? "stage-video"
            : "stage-music"
          : "pip";
      const slot = slotName
        ? document.querySelector<HTMLElement>(`[data-player-slot="${slotName}"]`)
        : null;
      if (!slot || !currentId) {
        host.style.opacity = "0";
        host.style.pointerEvents = "none";
        return;
      }
      const rect = slot.getBoundingClientRect();
      if (rect.width < 8 || rect.height < 8) {
        host.style.opacity = "0";
        return;
      }
      host.style.opacity = !stageOpen && mode === "music" ? "0.06" : "1";
      host.style.pointerEvents = stageOpen ? "auto" : "none";
      host.style.top = `${rect.top}px`;
      host.style.left = `${rect.left}px`;
      host.style.width = `${rect.width}px`;
      host.style.height = `${rect.height}px`;
      host.style.borderRadius = getComputedStyle(slot).borderRadius;
      try {
        playerRef.current?.setSize(
          Math.max(200, Math.round(rect.width)),
          Math.max(200, Math.round(rect.height)),
        );
      } catch {
        /* player may not be ready */
      }
    };

    sync();
    const observer = new ResizeObserver(sync);
    observer.observe(document.documentElement);
    window.addEventListener("resize", sync);
    window.addEventListener("scroll", sync, true);
    const interval = window.setInterval(sync, 200);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", sync);
      window.removeEventListener("scroll", sync, true);
      window.clearInterval(interval);
    };
  }, [currentId, mode, stageOpen]);

  useEffect(() => {
    if (!currentId) return;
    let cancelled = false;

    const applyQuality = (player: YTPlayer) => {
      const music = usePlayerStore.getState().mode === "music";
      try {
        player.setPlaybackQuality(music ? "tiny" : "large");
      } catch {
        /* quality hints are best-effort */
      }
    };

    const hardenIframe = (player: YTPlayer) => {
      try {
        const iframe = player.getIframe();
        iframe.setAttribute(
          "allow",
          "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
        );
        iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
        iframe.setAttribute("allowfullscreen", "true");
      } catch {
        /* iframe not ready */
      }
    };

    const startPoll = (player: YTPlayer) => {
      if (pollRef.current) return;
      pollRef.current = window.setInterval(() => {
        try {
          const t = player.getCurrentTime();
          const d = player.getDuration();
          if (Number.isFinite(t) && Number.isFinite(d)) {
            usePlayerStore.getState().setProgress(t, d || usePlayerStore.getState().duration);
          }
        } catch {
          /* destroyed */
        }
      }, 250);
    };

    void loadYouTubeAPI()
      .then((YT) => {
        if (cancelled || !playerElRef.current) return;
        const latestId = usePlayerStore.getState().current?.id;
        if (!latestId) return;

        if (playerRef.current) {
          playerRef.current.loadVideoById(latestId);
          applyQuality(playerRef.current);
          return;
        }

        const player = new YT.Player(playerElRef.current, {
          width: 640,
          height: 360,
          videoId: latestId,
          playerVars: {
            autoplay: 1,
            controls: 0,
            disablekb: 1,
            fs: 1,
            modestbranding: 1,
            rel: 0,
            iv_load_policy: 3,
            playsinline: 1,
            enablejsapi: 1,
            widget_referrer: window.location.href,
          },
          events: {
            onReady: (event) => {
              const store = usePlayerStore.getState();
              hardenIframe(event.target);
              event.target.setVolume(Math.round(store.volume * 100));
              if (store.muted) event.target.mute();
              applyQuality(event.target);
              event.target.playVideo();
              store.setReady(true);
              store.setProgress(0, event.target.getDuration() || store.duration);
            },
            onStateChange: (event) => {
              const store = usePlayerStore.getState();
              if (event.data === YT_STATE.ENDED) {
                failRef.current = 0;
                store.next();
              }
              if (event.data === YT_STATE.PLAYING) {
                failRef.current = 0;
                store.setPlaying(true);
                applyQuality(event.target);
                const duration = event.target.getDuration();
                if (duration) store.setProgress(event.target.getCurrentTime(), duration);
              }
              if (event.data === YT_STATE.PAUSED) store.setPlaying(false);
            },
            onError: () => {
              const now = Date.now();
              if (now - lastErrorRef.current < 1200) return;
              lastErrorRef.current = now;
              failRef.current += 1;
              if (failRef.current >= 4) {
                toast.error("Video ini tidak bisa diputar di sini. Coba judul lain.");
                usePlayerStore.getState().setPlaying(false);
                return;
              }
              window.setTimeout(() => usePlayerStore.getState().next(), 500);
            },
          },
        });
        playerRef.current = player;
        bindPlayerEngine({
          play: () => player.playVideo(),
          pause: () => player.pauseVideo(),
          seekTo: (seconds) => player.seekTo(seconds, true),
          setVolume: (v) => player.setVolume(Math.round(v * 100)),
          mute: () => player.mute(),
          unMute: () => player.unMute(),
          load: (id) => player.loadVideoById(id),
          setMusicQuality: (on) => {
            try {
              player.setPlaybackQuality(on ? "tiny" : "large");
            } catch {
              /* noop */
            }
          },
        });
        startPoll(player);
      })
      .catch((error: unknown) => {
        const message = error instanceof Error ? error.message : "Pemutar gagal dimuat";
        toast.error(message);
      });

    return () => {
      cancelled = true;
    };
  }, [currentId]);

  useEffect(() => {
    return () => {
      if (pollRef.current) window.clearInterval(pollRef.current);
      bindPlayerEngine(null);
      playerRef.current?.destroy();
      playerRef.current = null;
    };
  }, []);

  return (
    <div
      ref={hostRef}
      className={cn(
        "pointer-events-none fixed z-30 overflow-hidden bg-ink shadow-[var(--shadow-lift)] transition-opacity duration-200",
        !currentId && "hidden",
      )}
      style={{ opacity: 0 }}
      aria-hidden={mode === "music" || !stageOpen}
      onClick={() => {
        if (usePlayerStore.getState().mode === "music") {
          usePlayerStore.getState().togglePlay();
        }
      }}
    >
      <div ref={playerElRef} className="size-full" />
      {mode === "music" && currentThumb ? (
        <img
          src={currentThumb}
          alt=""
          className="pointer-events-none absolute inset-0 size-full object-cover"
        />
      ) : null}
    </div>
  );
}
