import { useEffect, useRef, useState } from "react";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { Film, LoaderCircle, Music2, Search, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { usePlayerStore } from "@/lib/player-store";
import { suggestYoutube } from "@/lib/youtube";

export function SearchHeader() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/" });
  const query = search.q ?? "";
  const [value, setValue] = useState(query);
  const [open, setOpen] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const mode = usePlayerStore((s) => s.mode);
  const setMode = usePlayerStore((s) => s.setMode);

  useEffect(() => {
    setValue(query);
  }, [query]);

  const suggestions = useQuery({
    queryKey: ["suggest", value],
    queryFn: () => suggestYoutube({ data: { query: value } }),
    enabled: value.trim().length >= 2 && value.trim() !== query,
    staleTime: 30_000,
  });

  const submit = (next: string) => {
    const q = next.trim();
    setOpen(false);
    void navigate({
      to: "/",
      search: q ? { q } : {},
    });
  };

  const items = suggestions.data ?? [];

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:gap-4 sm:px-6">
        <button
          type="button"
          className="flex shrink-0 items-baseline gap-1.5"
          onClick={() => {
            setValue("");
            void navigate({ to: "/", search: {} });
          }}
          aria-label="Beranda Nada"
        >
          <span className="font-display text-xl italic tracking-tight text-foreground sm:text-2xl">
            Nada
          </span>
        </button>

        <form
          ref={formRef}
          className="relative min-w-0 flex-1"
          onSubmit={(event) => {
            event.preventDefault();
            submit(value);
          }}
        >
          <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={value}
            onChange={(event) => {
              setValue(event.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => window.setTimeout(() => setOpen(false), 120)}
            placeholder="Cari lagu, artis, atau tautan YouTube"
            className="h-11 bg-secondary/80 pr-11 pl-10"
            aria-label="Cari musik atau video"
            autoComplete="off"
            enterKeyHint="search"
          />
          {value ? (
            <button
              type="button"
              className="absolute top-1/2 right-2 grid size-8 -translate-y-1/2 place-items-center rounded-full text-muted-foreground hover:text-foreground"
              aria-label="Hapus pencarian"
              onClick={() => {
                setValue("");
                submit("");
              }}
            >
              <X className="size-4" />
            </button>
          ) : suggestions.isFetching ? (
            <LoaderCircle className="absolute top-1/2 right-3.5 size-4 -translate-y-1/2 animate-spin text-muted-foreground" />
          ) : null}

          {open && items.length > 0 ? (
            <ul className="absolute inset-x-0 top-[calc(100%+8px)] z-50 overflow-hidden rounded-2xl bg-popover py-2 shadow-[var(--shadow-border),var(--shadow-lift)]">
              {items.map((item) => (
                <li key={item}>
                  <button
                    type="button"
                    className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm hover:bg-accent"
                    onMouseDown={(event) => event.preventDefault()}
                    onClick={() => {
                      setValue(item);
                      submit(item);
                    }}
                  >
                    <Search className="size-3.5 text-muted-foreground" />
                    <span className="truncate">{item}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </form>

        <div
          className="relative grid shrink-0 grid-cols-2 rounded-full bg-secondary p-1"
          role="radiogroup"
          aria-label="Mode putar"
        >
          <span
            className={cn(
              "absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-full bg-primary transition-transform duration-200 ease-[var(--ease-smooth-out)]",
              mode === "video" ? "translate-x-[calc(100%+4px)]" : "translate-x-0",
            )}
            aria-hidden
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            role="radio"
            aria-checked={mode === "music"}
            className={cn(
              "relative z-10 h-8 rounded-full px-2.5 text-xs sm:px-3",
              mode === "music" ? "text-primary-foreground hover:bg-transparent" : "text-muted-foreground",
            )}
            onClick={() => setMode("music")}
          >
            <Music2 className="size-3.5" />
            <span className="hidden sm:inline">Musik</span>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            role="radio"
            aria-checked={mode === "video"}
            className={cn(
              "relative z-10 h-8 rounded-full px-2.5 text-xs sm:px-3",
              mode === "video" ? "text-primary-foreground hover:bg-transparent" : "text-muted-foreground",
            )}
            onClick={() => setMode("video")}
          >
            <Film className="size-3.5" />
            <span className="hidden sm:inline">Video</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
