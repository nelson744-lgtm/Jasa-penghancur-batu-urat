import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ChevronDown,
  Heart,
  ListMusic,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { VideoCard } from "@/components/video-card";
import { cn, formatTime } from "@/lib/utils";
import { usePlayerStore, type RepeatMode } from "@/lib/player-store";
import { getRelated, type Track } from "@/lib/youtube";

export function PlayerChrome() {
  const current = usePlayerStore((s) => s.current);
  const appendRelated = usePlayerStore((s) => s.appendRelated);

  const related = useQuery({
    queryKey: ["related", current?.id],
    queryFn: () => getRelated({ data: { videoId: current!.id } }),
    enabled: Boolean(current?.id),
    staleTime: 5 * 60_000,
  });

  useEffect(() => {
    if (related.data) appendRelated(related.data);
  }, [appendRelated, related.data]);

  if (!current) return null;

  return (
    <>
      <PlayerStage related={related.data ?? []} />
      <PlayerDock />
      <QueueDrawer />
    </>
  );
}

function PlayerStage({ related }: { related: Track[] }) {
  const current = usePlayerStore((s) => s.current);
  const queue = usePlayerStore((s) => s.queue);
  const mode = usePlayerStore((s) => s.mode);
  const stageOpen = usePlayerStore((s) => s.stageOpen);
  const setStageOpen = usePlayerStore((s) => s.setStageOpen);
  const isPlaying = usePlayerStore((s) => s.isPlaying);
  const togglePlay = usePlayerStore((s) => s.togglePlay);

  if (!current || !stageOpen) return null;

  const upNext = (related.length > 0 ? related : queue.filter((t) => t.id !== current.id)).slice(
    0,
    10,
  );

  return (
    <section className="relative mb-8 rise-in">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          {mode === "music" ? "Mode musik · hemat data" : "Mode video"}
        </p>
        <Button type="button" variant="ghost" size="sm" onClick={() => setStageOpen(false)}>
          <ChevronDown className="size-4" />
          Ciutkan
        </Button>
      </div>

      {mode === "video" ? (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div
            data-player-slot="stage-video"
            className="aspect-video w-full overflow-hidden rounded-2xl bg-ink shadow-[var(--shadow-border)]"
          />
          <aside className="hidden min-h-0 lg:block">
            <h2 className="mb-3 text-sm font-medium">Berikutnya</h2>
            <div className="max-h-[28rem] space-y-1 overflow-y-auto pr-1">
              {upNext.map((track, index) => (
                <VideoCard key={track.id} track={track} queue={upNext} layout="row" index={index} />
              ))}
            </div>
          </aside>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-6 py-2">
          <button
            type="button"
            onClick={togglePlay}
            className="relative"
            aria-label={isPlaying ? "Jeda" : "Putar"}
          >
            <div
              data-player-slot="stage-music"
              className="size-[min(72vw,380px)] overflow-hidden rounded-[28px] bg-secondary shadow-[var(--shadow-lift)]"
            />
            {!isPlaying ? (
              <span className="pointer-events-none absolute inset-0 grid place-items-center">
                <span className="grid size-16 place-items-center rounded-full bg-primary text-primary-foreground">
                  <Play className="size-7 fill-current ml-0.5" />
                </span>
              </span>
            ) : null}
          </button>
          <div className="w-full max-w-md text-center">
            <h2 className="font-display text-2xl leading-snug tracking-tight italic">{current.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{current.channel}</p>
          </div>
          <div className="w-full max-w-md">
            <SeekBar />
            <Transport large />
          </div>
        </div>
      )}
    </section>
  );
}

function PlayerDock() {
  const current = usePlayerStore((s) => s.current);
  const isPlaying = usePlayerStore((s) => s.isPlaying);
  const togglePlay = usePlayerStore((s) => s.togglePlay);
  const stageOpen = usePlayerStore((s) => s.stageOpen);
  const setStageOpen = usePlayerStore((s) => s.setStageOpen);
  const queueOpen = usePlayerStore((s) => s.queueOpen);
  const setQueueOpen = usePlayerStore((s) => s.setQueueOpen);
  const liked = usePlayerStore((s) => (s.current ? s.isLiked(s.current.id) : false));
  const toggleLike = usePlayerStore((s) => s.toggleLike);
  const mode = usePlayerStore((s) => s.mode);

  if (!current) return null;

  return (
    <>
      {!stageOpen ? (
        <div
          data-player-slot="pip"
          className="pointer-events-none fixed right-4 bottom-24 z-20 size-[200px] overflow-hidden rounded-2xl opacity-0"
        />
      ) : null}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 px-3 pb-[calc(12px+env(safe-area-inset-bottom))] sm:px-4">
        <div className="pointer-events-auto mx-auto max-w-6xl rounded-2xl bg-card/95 p-2 shadow-[var(--shadow-border),var(--shadow-lift)] backdrop-blur-md sm:p-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="flex min-w-0 flex-1 items-center gap-3 text-left"
              onClick={() => setStageOpen(!stageOpen)}
            >
              <img
                src={current.thumbnail}
                alt=""
                className="size-12 rounded-lg object-cover sm:size-14"
              />
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium">{current.title}</span>
                <span className="block truncate text-xs text-muted-foreground">{current.channel}</span>
              </span>
            </button>

            <div className="hidden min-w-0 flex-[1.2] flex-col sm:flex">
              <Transport />
              <SeekBar />
            </div>

            <div className="flex items-center gap-0.5">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-10"
                aria-label={liked ? "Hapus dari disukai" : "Sukai"}
                onClick={() => toggleLike()}
              >
                <Heart className={cn("size-4", liked && "fill-current text-destructive")} />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-11 sm:hidden"
                aria-label={isPlaying ? "Jeda" : "Putar"}
                onClick={togglePlay}
              >
                {isPlaying ? (
                  <Pause className="size-5 fill-current" />
                ) : (
                  <Play className="size-5 fill-current ml-0.5" />
                )}
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="hidden size-10 md:inline-flex"
                aria-label={queueOpen ? "Tutup antrian" : "Buka antrian"}
                onClick={() => setQueueOpen(!queueOpen)}
              >
                <ListMusic className="size-4" />
              </Button>
              <VolumeControl />
            </div>
          </div>
          <p className="mt-1 hidden px-1 text-[11px] text-muted-foreground sm:block">
            {mode === "music" ? "Kualitas rendah untuk hemat kuota" : "Video penuh"}
          </p>
        </div>
      </div>
    </>
  );
}

function Transport({ large = false }: { large?: boolean }) {
  const isPlaying = usePlayerStore((s) => s.isPlaying);
  const togglePlay = usePlayerStore((s) => s.togglePlay);
  const next = usePlayerStore((s) => s.next);
  const prev = usePlayerStore((s) => s.prev);
  const shuffle = usePlayerStore((s) => s.shuffle);
  const toggleShuffle = usePlayerStore((s) => s.toggleShuffle);
  const repeat = usePlayerStore((s) => s.repeat);
  const cycleRepeat = usePlayerStore((s) => s.cycleRepeat);

  const RepeatIcon = repeat === "one" ? Repeat1 : Repeat;

  return (
    <div className={cn("flex items-center justify-center gap-1", large && "gap-2")}>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className={cn("size-10", shuffle && "text-primary")}
        aria-label="Acak"
        aria-pressed={shuffle}
        onClick={toggleShuffle}
      >
        <Shuffle className="size-4" />
      </Button>
      <Button type="button" variant="ghost" size="icon" className="size-10" aria-label="Sebelumnya" onClick={prev}>
        <SkipBack className="size-4 fill-current" />
      </Button>
      <Button
        type="button"
        variant="default"
        size="icon"
        className={cn("size-11", large && "size-14")}
        aria-label={isPlaying ? "Jeda" : "Putar"}
        onClick={togglePlay}
      >
        {isPlaying ? (
          <Pause className={cn("size-5 fill-current", large && "size-6")} />
        ) : (
          <Play className={cn("size-5 fill-current ml-0.5", large && "size-6")} />
        )}
      </Button>
      <Button type="button" variant="ghost" size="icon" className="size-10" aria-label="Berikutnya" onClick={next}>
        <SkipForward className="size-4 fill-current" />
      </Button>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className={cn("size-10", repeat !== "off" && "text-primary")}
        aria-label={repeatLabel(repeat)}
        onClick={cycleRepeat}
      >
        <RepeatIcon className="size-4" />
      </Button>
    </div>
  );
}

function SeekBar() {
  const currentTime = usePlayerStore((s) => s.currentTime);
  const duration = usePlayerStore((s) => s.duration);
  const seek = usePlayerStore((s) => s.seek);
  const max = duration > 0 ? duration : 0;

  return (
    <div className="flex items-center gap-2 px-1">
      <span className="w-9 text-right text-[11px] tabular-nums text-muted-foreground">
        {formatTime(currentTime)}
      </span>
      <Slider
        min={0}
        max={max || 1}
        step={0.5}
        value={[Math.min(currentTime, max)]}
        onValueChange={(value) => seek(value[0] ?? 0)}
        aria-label="Posisi lagu"
        disabled={max <= 0}
      />
      <span className="w-9 text-[11px] tabular-nums text-muted-foreground">{formatTime(max)}</span>
    </div>
  );
}

function VolumeControl() {
  const volume = usePlayerStore((s) => s.volume);
  const muted = usePlayerStore((s) => s.muted);
  const setVolume = usePlayerStore((s) => s.setVolume);
  const toggleMute = usePlayerStore((s) => s.toggleMute);

  return (
    <div className="hidden items-center gap-1 lg:flex">
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="size-10"
        aria-label={muted ? "Bunyi" : "Bisukan"}
        onClick={toggleMute}
      >
        {muted || volume === 0 ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
      </Button>
      <Slider
        className="w-24"
        min={0}
        max={1}
        step={0.01}
        value={[muted ? 0 : volume]}
        onValueChange={(value) => setVolume(value[0] ?? 0)}
        aria-label="Volume"
      />
    </div>
  );
}

function QueueDrawer() {
  const queueOpen = usePlayerStore((s) => s.queueOpen);
  const setQueueOpen = usePlayerStore((s) => s.setQueueOpen);
  const queue = usePlayerStore((s) => s.queue);
  const queueIndex = usePlayerStore((s) => s.queueIndex);
  const playAt = usePlayerStore((s) => s.playAt);

  if (!queueOpen) return null;

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-label="Antrian">
      <button
        type="button"
        className="absolute inset-0 bg-ink/50"
        aria-label="Tutup antrian"
        onClick={() => setQueueOpen(false)}
      />
      <div className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-card shadow-[var(--shadow-lift)]">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h2 className="text-sm font-medium">Antrian · {queue.length}</h2>
          <Button type="button" variant="ghost" size="icon" className="size-10" onClick={() => setQueueOpen(false)}>
            <X className="size-4" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {queue.map((track, index) => (
            <button
              type="button"
              key={`${track.id}-${index}`}
              onClick={() => playAt(index)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-accent",
                index === queueIndex && "bg-accent",
              )}
            >
              <img src={track.thumbnail} alt="" className="size-12 rounded-md object-cover" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm">{track.title}</span>
                <span className="block truncate text-xs text-muted-foreground">{track.channel}</span>
              </span>
              <span className="text-[11px] tabular-nums text-muted-foreground">{track.durationLabel}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function repeatLabel(repeat: RepeatMode) {
  if (repeat === "one") return "Ulangi satu lagu";
  if (repeat === "all") return "Ulangi antrian";
  return "Ulangi mati";
}
