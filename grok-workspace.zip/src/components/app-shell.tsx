import { useEffect } from "react";
import { SearchHeader } from "@/components/search-header";
import { Catalog, CatalogTabs } from "@/components/catalog";
import { PlayerChrome } from "@/components/player-chrome";
import { PlayerEngine } from "@/components/player-engine";
import { usePlayerStore } from "@/lib/player-store";
import { cn } from "@/lib/utils";

export function AppShell() {
  const hasTrack = usePlayerStore((s) => Boolean(s.current));

  useEffect(() => {
    void Promise.resolve(usePlayerStore.persist.rehydrate()).then(() => {
      usePlayerStore.getState().setHydrated();
    });
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (typing) return;
      const store = usePlayerStore.getState();
      if (!store.current) return;
      if (event.code === "Space") {
        event.preventDefault();
        store.togglePlay();
      } else if (event.code === "ArrowRight") {
        store.seek(store.currentTime + 5);
      } else if (event.code === "ArrowLeft") {
        store.seek(Math.max(0, store.currentTime - 5));
      } else if (event.key === "n" || event.key === "N") {
        store.next();
      } else if (event.key === "p" || event.key === "P") {
        store.prev();
      } else if (event.key === "m" || event.key === "M") {
        store.toggleMute();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const current = usePlayerStore((s) => s.current);

  useEffect(() => {
    if (!current || !("mediaSession" in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: current.title,
      artist: current.channel,
      artwork: [{ src: current.thumbnail, sizes: "320x180", type: "image/jpeg" }],
    });
    navigator.mediaSession.setActionHandler("play", () => {
      const store = usePlayerStore.getState();
      if (!store.isPlaying) store.togglePlay();
    });
    navigator.mediaSession.setActionHandler("pause", () => {
      const store = usePlayerStore.getState();
      if (store.isPlaying) store.togglePlay();
    });
    navigator.mediaSession.setActionHandler("previoustrack", () => {
      usePlayerStore.getState().prev();
    });
    navigator.mediaSession.setActionHandler("nexttrack", () => {
      usePlayerStore.getState().next();
    });
  }, [current]);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <SearchHeader />
      <main
        className={cn("mx-auto max-w-6xl px-4 pt-6 sm:px-6", hasTrack ? "pb-36" : "pb-16")}
      >
        <PlayerChrome />
        <CatalogTabs />
        <Catalog />
      </main>
      <PlayerEngine />
    </div>
  );
}
