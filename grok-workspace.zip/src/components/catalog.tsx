import { useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Heart, History, House, Play, SearchX } from "lucide-react";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { VideoCard } from "@/components/video-card";
import { extractYoutubeId, greetingId } from "@/lib/utils";
import { usePlayerStore } from "@/lib/player-store";
import { getHomeFeed, resolveVideo, searchYoutube } from "@/lib/youtube";

export function Catalog() {
  const search = useSearch({ from: "/" });
  const query = search.q?.trim() ?? "";
  const tab = search.tab ?? "home";

  if (query) return <SearchResults query={query} />;
  if (tab === "likes") return <LibraryList kind="likes" />;
  if (tab === "history") return <LibraryList kind="history" />;
  return <BrowseHome />;
}

export function CatalogTabs() {
  const search = useSearch({ from: "/" });
  const navigate = useNavigate();
  const query = search.q?.trim() ?? "";
  const tab = search.tab ?? "home";
  if (query) return null;

  const go = (next: "home" | "likes" | "history") => {
    void navigate({
      to: "/",
      search: next === "home" ? {} : { tab: next },
    });
  };

  return (
    <div className="mb-6 flex gap-2">
      <TabChip active={tab === "home"} onClick={() => go("home")} icon={<House className="size-3.5" />}>
        Jelajah
      </TabChip>
      <TabChip active={tab === "likes"} onClick={() => go("likes")} icon={<Heart className="size-3.5" />}>
        Disukai
      </TabChip>
      <TabChip
        active={tab === "history"}
        onClick={() => go("history")}
        icon={<History className="size-3.5" />}
      >
        Riwayat
      </TabChip>
    </div>
  );
}

function TabChip({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <Button
      type="button"
      variant={active ? "default" : "secondary"}
      size="pill"
      className="h-9"
      onClick={onClick}
    >
      {icon}
      {children}
    </Button>
  );
}

function BrowseHome() {
  const feed = useQuery({
    queryKey: ["home-feed"],
    queryFn: () => getHomeFeed(),
  });
  const playTrack = usePlayerStore((s) => s.playTrack);
  const [hello, setHello] = useState("Selamat datang");

  useEffect(() => {
    setHello(greetingId());
  }, []);

  if (feed.isError) {
    return (
      <EmptyState
        title="Katalog belum bisa dimuat"
        body={feed.error instanceof Error ? feed.error.message : "Coba muat ulang."}
        action={
          <Button type="button" onClick={() => void feed.refetch()}>
            Coba lagi
          </Button>
        }
      />
    );
  }

  const hero = feed.data?.[0]?.tracks[0];
  const heroQueue = feed.data?.[0]?.tracks ?? [];

  return (
    <div className="space-y-10">
      <section className="rise-in">
        <p className="text-sm text-muted-foreground">{hello}</p>
        <h1 className="font-display mt-1 max-w-xl text-3xl leading-tight tracking-tight italic sm:text-4xl">
          Putar apa saja dari YouTube, tanpa ribet.
        </h1>
      </section>

      {feed.isLoading || !hero ? (
        <HeroSkeleton />
      ) : (
        <section className="relative overflow-hidden rounded-3xl bg-card shadow-[var(--shadow-border)]">
          <button
            type="button"
            className="relative block w-full text-left tap-press"
            onClick={() => playTrack(hero, heroQueue)}
            aria-label={`Putar ${hero.title}`}
          >
            <span className="relative block aspect-[16/9] sm:aspect-[2.15/1]">
              <img src={hero.thumbnail} alt="" className="absolute inset-0 size-full object-cover" />
              <span className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/15" />
              <span className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
            </span>
            <span className="absolute inset-0 flex flex-col justify-end gap-3 p-5 sm:max-w-lg sm:p-7">
              <span className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
                Pilihan hari ini
              </span>
              <span className="font-display text-2xl leading-snug tracking-tight italic sm:text-3xl">
                {hero.title}
              </span>
              <span className="text-sm text-muted-foreground">{hero.channel}</span>
              <span className="mt-1 inline-flex h-11 w-fit items-center gap-2 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground">
                <Play className="size-4 fill-current ml-0.5" />
                Putar
              </span>
            </span>
          </button>
        </section>
      )}

      {feed.isLoading
        ? Array.from({ length: 3 }).map((_, i) => <RailSkeleton key={i} />)
        : feed.data?.map((section) => (
            <section key={section.id} className="min-w-0">
              <div className="mb-3">
                <h2 className="text-lg font-medium tracking-tight">{section.title}</h2>
                <p className="text-sm text-muted-foreground">{section.subtitle}</p>
              </div>
              <div className="rail">
                {section.tracks.map((track, index) => (
                  <VideoCard
                    key={track.id}
                    track={track}
                    queue={section.tracks}
                    layout="rail"
                    index={index}
                  />
                ))}
              </div>
            </section>
          ))}
    </div>
  );
}

function SearchResults({ query }: { query: string }) {
  const videoId = extractYoutubeId(query);
  const playTrack = usePlayerStore((s) => s.playTrack);
  const playedId = useRef<string | null>(null);

  const resolved = useQuery({
    queryKey: ["resolve", videoId],
    queryFn: () => resolveVideo({ data: { videoId: videoId! } }),
    enabled: Boolean(videoId),
  });

  const results = useQuery({
    queryKey: ["search", query],
    queryFn: () => searchYoutube({ data: { query } }),
    enabled: !videoId,
  });

  useEffect(() => {
    if (!resolved.data) return;
    if (playedId.current === resolved.data.id) return;
    playedId.current = resolved.data.id;
    playTrack(resolved.data);
  }, [playTrack, resolved.data]);

  if (videoId) {
    return (
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">Membuka tautan YouTube…</p>
        {resolved.isError ? (
          <EmptyState
            title="Tautan tidak bisa dibuka"
            body={resolved.error instanceof Error ? resolved.error.message : "Coba tempel ulang."}
          />
        ) : (
          <GridSkeleton />
        )}
      </div>
    );
  }

  if (results.isLoading) {
    return (
      <div>
        <h1 className="mb-4 text-lg font-medium">Mencari “{query}”</h1>
        <GridSkeleton />
      </div>
    );
  }

  if (results.isError) {
    return (
      <EmptyState
        title="Pencarian gagal"
        body={results.error instanceof Error ? results.error.message : "Coba lagi."}
        action={
          <Button type="button" onClick={() => void results.refetch()}>
            Coba lagi
          </Button>
        }
      />
    );
  }

  const tracks = results.data?.tracks ?? [];
  if (tracks.length === 0) {
    return (
      <EmptyState
        title="Tidak ada hasil"
        body={`Tidak ketemu untuk “${query}”. Coba judul lagu atau nama artis.`}
      />
    );
  }

  return (
    <div>
      <h1 className="mb-1 text-lg font-medium">Hasil untuk “{query}”</h1>
      <p className="mb-5 text-sm text-muted-foreground">{tracks.length} video</p>
      <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4">
        {tracks.map((track, index) => (
          <VideoCard key={track.id} track={track} queue={tracks} layout="grid" index={index} />
        ))}
      </div>
    </div>
  );
}

function LibraryList({ kind }: { kind: "likes" | "history" }) {
  const hydrated = usePlayerStore((s) => s.hydrated);
  const likes = usePlayerStore((s) => s.likes);
  const history = usePlayerStore((s) => s.history);
  const tracks = kind === "likes" ? likes : history;
  const title = kind === "likes" ? "Disukai" : "Riwayat";
  const empty =
    kind === "likes"
      ? "Lagu yang kamu sukai akan terkumpul di sini."
      : "Putar sesuatu, riwayatnya akan muncul di sini.";

  if (!hydrated) return <GridSkeleton />;
  if (tracks.length === 0) {
    return <EmptyState title={title} body={empty} />;
  }

  return (
    <div>
      <h1 className="mb-5 text-lg font-medium">{title}</h1>
      <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4">
        {tracks.map((track, index) => (
          <VideoCard key={track.id} track={track} queue={tracks} layout="grid" index={index} />
        ))}
      </div>
    </div>
  );
}

function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
      <SearchX className="size-8 text-muted-foreground" />
      <h2 className="text-lg font-medium">{title}</h2>
      <p className="max-w-sm text-sm text-muted-foreground">{body}</p>
      {action}
    </div>
  );
}

function HeroSkeleton() {
  return <Skeleton className="h-[280px] w-full rounded-3xl" />;
}

function RailSkeleton() {
  return (
    <div>
      <Skeleton className="mb-3 h-5 w-40" />
      <div className="flex gap-3 overflow-hidden">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="w-[168px] shrink-0 sm:w-[200px]">
            <Skeleton className="aspect-video w-full rounded-xl" />
            <Skeleton className="mt-2 h-4 w-4/5" />
            <Skeleton className="mt-1 h-3 w-1/2" />
          </div>
        ))}
      </div>
    </div>
  );
}

function GridSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i}>
          <Skeleton className="aspect-video w-full rounded-xl" />
          <Skeleton className="mt-2 h-4 w-4/5" />
          <Skeleton className="mt-1 h-3 w-1/2" />
        </div>
      ))}
    </div>
  );
}
